PIOS.exe sample1
pause