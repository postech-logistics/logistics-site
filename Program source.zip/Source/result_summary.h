#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include "item.h"

using namespace std;

class result_summary {
public:
	int num_of_work_operation;
	int  num_of_hanger; // Total number of used hangers
	int  start_time; // Work starting time
	int  finish_time; // Work completion time

	double mix_case;
	double continuoust_case;
	double capacity_loss;

	double mixCost;  //c1
	double maxP;  //c2
	double partiallyHungItems;  //c4
	double productivity;  //c5
	double separationPenalty;  //c6

	double mixCost_weight;  //c1*weight
	double maxP_weight;  //c2*weight
	double capacity_loss_weight;  //c3*weight
	double partiallyHungItems_weight;  //c4*weight
	double productivity_weight;  //c5*weight

	double total_objective;
};
void write_summary(result_summary &summary, char* filename, double elapsed_secs);