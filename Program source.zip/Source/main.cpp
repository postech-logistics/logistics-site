#include "item.h"
#include "info.h"
#include "operation.h"
#include <vector>
#include <iostream>
#include <fstream>
#include "controller.h"
#include "mix_standard.h"
#include <ctime>
#include "result_summary.h"
using namespace std;

ofstream log_out;
int main(int argc, char* argv[]) {

	int hanger = 0;
	vector<c_item> v_items;
	vector<c_item> v_items_to_schedule;
	vector<c_info> v_info;
	vector<pack> v_pack;
	C_line line_input;
	vector<c_basic_hanger> basic_hanger_list;
	vector<c_hanger> v_hangers;
	vector<c_parameter> param;
	vector<c_operation> v_operations;
	vector<c_mix_standard> v_mix_stands;
	result_summary summary;

	log_out.open("./program_log_file.txt");
	if (!log_out.is_open())
		throw 2;
	try {
		if (argc < 9) {
			log_out << "This program requires 9 files and 1 comment (type of algorithm in batch file). " <<
				"Please provide input following the requested format: HantalSchedulingProgram.exe 1(TabuSearch)/2(2-Opt)(in_batch_file) packing_information.csv parameter.csv mix_information.csv v_items_to_schedule.csv hanger_input.csv production_plan_order.csv summary.csv hanger_summary.csv" << endl;
			throw - 1;
		}

		const char* algorithm_type_char = argv[1];
		int algorithm_type = atoi(algorithm_type_char);

		readPackInfo(argv[2], v_pack);
		readParameters(argv[3], param);
		read_mix_standard_info(v_mix_stands, argv[4]);
		read_hanger_input(v_hangers, argv[6]);

		clock_t begin = clock();

		read_item_info(argv[5], v_items_to_schedule);

		vector<c_item> v_input_items;
		for (int i = 0; i < (int)v_items_to_schedule.size(); i++) {
			v_input_items.push_back(v_items_to_schedule[i]);
		}

		clock_t before = clock();

		simple_heuristic(v_items_to_schedule, v_hangers, param, v_pack, v_mix_stands, summary, algorithm_type);

		make_operation3(v_hangers, v_operations);
		summary.num_of_work_operation = (int) v_operations.size();
		
		writeSchedule(v_hangers, v_operations, argv[7]);

		clock_t end = clock();
		double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

		write_summary(summary, argv[8], elapsed_secs);

		writeScheduleOnHangers(v_hangers, v_input_items, argv[9]);

		v_items.clear();
		v_items_to_schedule.clear();
		v_hangers.clear();
		log_out << "Elapsed time = " << elapsed_secs <<"sec"<< endl;
		log_out << "The program is terminated successfully" << endl;
		log_out << flush;
		cout << "The program is terminated successfully" << endl;
		log_out.close();

		return 1;

	}
	catch (string error_message) {
		if (error_message == "finish_time_is_earlier_than_dinner_time") {
			log_out << "Finish time is earlier than dinner time. Please set dinner time request into n/N or set the dinner time later." << endl;
		}
		if (error_message == "hanger_generation_error") {
			log_out << "Please check the next case" << endl;
			log_out << "1) Speed of the hanger in the inputted hanger information is 0. Hanger's speed is the time needed for one hanger to pass (in seconds)." << endl;
			log_out << "2) Number of hangers in the hanger information and in the line information do not match." << endl;
			log_out << "3) Start hanger number is larger than the total number of hangers" << endl;
		}

		if (error_message == "cannot_find_penalty") {
			log_out << "Cannot find the penalty value in the mix information file." << endl;
		}
		log_out << "The program is terminated-1." << endl;
		log_out.close();
		return -1;
	}
	catch (int exception) {
		
		if (exception == 8) {
			log_out << "An exception in read_mix_standard_info. " << argv[4] << "The file cannot be opened. " << endl;
		}
		log_out << "Please check the input. The program is terminated." << endl;
		log_out.close();
		return -1;
	}
	catch (...) {
		log_out<< "exception" << endl;
		log_out << "exception" << endl;
		log_out.close();
		return -1;
	}
}