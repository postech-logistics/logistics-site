#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include "hanger.h"

c_hanger::c_hanger() {
	this->full = false;
	this->hanger_num = -1;
	this->hanger_num_original = -1;
	this->liquid_check = false;
	this->capacity_percentage = 100;
	this->available_group = 5;
}
c_hanger::c_hanger(int _hanger_num) : hanger_num_original(_hanger_num) {
	full = false;
	this->hanger_num = -1;
	this->liquid_check = false;
	this->capacity_percentage = 100;
	this->available_group = 5;
}

void c_hanger::hang(c_item& item, int& amt) {
	if (full == false && capacity_percentage > 0) {
		this->capacity_percentage -= ((amt * 100) / item.capa);
		if (this->capacity_percentage < -1)
			log_out << "capacity is negative";
		this->item_list.push_back(item);
		this->item_amt.push_back(amt);
	}
	else {
		log_out << "hanger " << this->hanger_num << "is full" << endl;
		throw 5;
	}
	if (this->capacity_percentage == 0.0)
		this->full = true;
}

bool c_hanger::eligibility_check(c_item & item)
{
	switch (this->available_group) {
	case 1: // Break time or normal loss
		return false;
		break;
	case 2: // Okay for interior items
		if (item.item_group == "BP02" || item.item_group == "BP02 " || item.item_group == "E001" || item.item_group == "PP01" || item.item_group == "ZZZZ" || item.pack_load <= 1)
			return true;
		else return false;
		break;
	case 3: // Lunch time
		if (item.type_code == "DK" || item.type_code == "DH" || item.pack_load <= 2)
			return true;
		else return false;
		break;
	case 4: // Everything is okay
		return true;
		break;
	default:
		log_out << "available group is 1~4 and" << this->available_group << "is not designated" << endl;
		throw 10;
		break;

	}
}

void setHangerClear(vector<c_hanger>& v_hangers) {
	for (int h = 0; h < (int)v_hangers.size(); h++) {
		v_hangers[h].capacity_percentage = 100;
		v_hangers[h].item_list.clear();
		v_hangers[h].item_amt.clear();
		v_hangers[h].full = false;
	}
}

void read_hanger_input(vector<c_hanger>& v_hangers, char* filename)
{
	ifstream fin;
	fin.open(filename);
	if (fin.is_open()) {

		string temp;
		getline(fin, temp);

		string v_hanger_index, available_group;

		int num_of_hangers = 0;
		while (!fin.eof()) {
			v_hanger_index = "";
			getline(fin, v_hanger_index);
			if (v_hanger_index == "") break;
			num_of_hangers = num_of_hangers + 1;
		}
		v_hangers.assign(num_of_hangers, c_hanger());

		fin.close();
	}
	else throw 9;

	fin.open(filename);
	if (fin.is_open()) {

		string temp;
		getline(fin, temp);

		string v_hanger_index, available_group;
		int i = 0;
		while (!fin.eof()) {
			v_hanger_index = "";
			getline(fin, v_hanger_index, ',');
			if (v_hanger_index == "") break;
			getline(fin, available_group);

			v_hangers[i].hanger_num = i + 1;
			v_hangers[i].available_group = atoi(available_group.c_str());
			i = i + 1;
		}

		fin.close();
	}
	else throw 9;
}