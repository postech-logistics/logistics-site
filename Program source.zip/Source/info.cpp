#include "item.h"
#include "info.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <vector>
#include <iterator>

using namespace std;

c_info::c_info()
{
	this->item_code = "default";
	this->type_code = "default";
	this->line_code = "default";
	this->main_line = false;
	this->needed_hanger = -1;
	this->hanger_capa = -1;
	this->voltage = -1;
	this->small_hang = false;
}

c_info::c_info(string _item_code, string _type_code, string _line_code, bool _main_line,
	int _needed_hanger, double _hanger_capa, int _voltage, bool _small_hang) {
	this->item_code = _item_code;
	this->type_code = _type_code;
	this->line_code = _line_code;
	this->main_line = _main_line;
	this->needed_hanger = _needed_hanger;
	this->hanger_capa = _hanger_capa;
	this->voltage = _voltage;
	this->small_hang = _small_hang;
}