#include <fstream>
#include <iostream>
#include <string>
#include "mix_standard.h"

using namespace std;
void read_mix_standard_info(vector<c_mix_standard>& mix_standard, char * filename)
{
	ifstream fin;
	fin.open(filename);
	if (fin.is_open()) {

		string temp;
		getline(fin, temp);

		string priority, type, pack, item_name, sub_assembly, model;
		while (!fin.eof()) {
			priority = "";
			getline(fin, priority, ',');
			if (priority == "") break;
			getline(fin, type, ',');
			getline(fin, pack, ',');
			getline(fin, item_name, ',');
			getline(fin, sub_assembly, ',');
			getline(fin, model);

			bool check_type, check_pack, check_name, check_sub_assembly, check_model;
			check_type = (atoi(type.c_str()) == 1 || type == "true" || type == "TRUE") ? true : false;
			check_pack = (atoi(pack.c_str()) == 1 || pack == "true" || pack == "TRUE") ? true : false;
			check_name = (atoi(item_name.c_str()) == 1 || item_name == "true" || item_name == "TRUE") ? true : false;
			check_sub_assembly = (atoi(sub_assembly.c_str()) == 1 || sub_assembly == "true" || sub_assembly == "TRUE") ? true : false;
			check_model = (atoi(model.c_str()) == 1 || model == "true" || model == "TRUE") ? true : false;
			c_mix_standard temp(atoi(priority.c_str()), check_type, check_pack, check_name, check_sub_assembly, check_model);
			mix_standard.push_back(temp);
		}
		fin.close();
	}
	else throw 8;
}

int search_penalty(vector<c_mix_standard> &mix_standard, bool _type, bool _pack, bool _item_name, bool _sub_assembly, bool _model)
{
	for (int i = 0; i < mix_standard.size(); i++) {
		if (mix_standard[i].type == _type && mix_standard[i].pack == _pack && mix_standard[i].item_name == _item_name && mix_standard[i].sub_assembly == _sub_assembly && mix_standard[i].car_model == _model)
			return mix_standard[i].mix_penalty;
	}
	
	log_out << "cannot find the penalty of type: " << _type << " , pack: " << _pack << ", item_name: " << _item_name << ", sub_assembly: " << _sub_assembly << endl;
	throw "cannot_find_penalty";
}
