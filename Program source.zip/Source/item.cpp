#include "item.h"
#include "hanger.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <vector>
#include <ctime>
#include <cmath>
#include <sstream>

using namespace std;


c_item::c_item() {}

c_item::c_item(string inp_num, int inp_ord, string inp_time, string inp_comp,
	string itm_code, string typ_code, string prd_type, string itm_name, double amt) {
	this->item_code = itm_code;
	this->type_code = typ_code;
	this->item_name = itm_name;
	this->amount = amt;
}

c_item::c_item(string _type_code, string _item_code) : item_code(_item_code), type_code(_type_code) {}

c_item::c_item(double amount, string available, double capa, string car_model, string car_model_name, int dayMaxHanger, string input_comp, string input_num, int input_order,
	string input_time, string item_code, string item_group, string item_name, string sub_assembly_name, string line_code, bool main_line, int maxHangerNum, int max_middle_nonpack, int min_middle_nonpack,
	int needed_hanger, int pack_load, string pack_type, string product_type, double remain, double remained_amount, bool small_hang, string type_code, int voltage) {
	this->amount = amount;
	this->capa = capa;
	this->car_model = car_model;
	this->dayMaxHanger = dayMaxHanger;
	this->item_code = item_code;
	this->item_group = item_group;
	this->item_name = item_name;
	this->sub_assembly_name = sub_assembly_name;
	this->maxHangerNum = maxHangerNum;
	this->max_middle_nonpack = max_middle_nonpack;
	this->min_middle_nonpack = min_middle_nonpack;
	this->needed_hanger = needed_hanger;
	this->pack_load = pack_load;
	this->pack_type = pack_type;
	this->remained_amount = remained_amount;
	this->type_code = type_code;
	this->voltage = voltage;
}

void readPackInfo(char* filename, vector<pack>& v_pack)
{
	fstream fin;
	string temp, pack_type, workload, maxHanger, minMiddle, maxMiddle, dayMax;

	fin.open(filename);
	if (fin.is_open()) {
		getline(fin, temp); // Not including the title
		for (; !fin.eof();) {
			workload = "";
			getline(fin, pack_type, ',');
			getline(fin, workload, ',');
			if (workload == "")break;
			getline(fin, maxHanger, ',');
			getline(fin, minMiddle, ',');
			getline(fin, maxMiddle, ',');
			getline(fin, dayMax);
			pack samplePack;
			samplePack.packType = pack_type;
			samplePack.workLoad = atoi(workload.c_str());
			samplePack.maxHangerNum = atoi(maxHanger.c_str());
			samplePack.min_middle_nonpack = atoi(minMiddle.c_str());
			samplePack.max_middle_nonpack = atoi(maxMiddle.c_str());
			samplePack.dayMaxHanger = atoi(dayMax.c_str());
			v_pack.push_back(samplePack);
		}
		fin.close();
	}
	else {
		log_out << "packing_information file is not opened" << endl;
		throw 6;
	}
}

void read_item_info(char* filename, vector<c_item>& v_items_to_schedule)
{
	fstream fin;
	string temp, amount, capa, car_model, dayMaxHanger, item_code, item_group, item_name, sub_assembly_name, maxHangerNum, max_middle_nonpack,
		min_middle_nonpack, needed_hanger, pack_load, pack_type, remained_amount, type_code;

	fin.open(filename);
	if (fin.is_open()) {
		getline(fin, temp); // Not including the title
		for (; !fin.eof();) {
			getline(fin, item_code, ',');
			if (item_code == "")break;
			getline(fin, item_name, ',');
			getline(fin, amount, ',');
			getline(fin, capa, ',');
			getline(fin, needed_hanger, ',');
			getline(fin, pack_load, ',');
			getline(fin, maxHangerNum, ',');
			getline(fin, max_middle_nonpack, ',');
			getline(fin, min_middle_nonpack, ',');
			getline(fin, dayMaxHanger, ',');
			getline(fin, type_code, ',');
			getline(fin, pack_type, ',');
			getline(fin, sub_assembly_name, ',');
			getline(fin, car_model, ',');
			getline(fin, item_group);

			c_item item;
			item.amount = atoi(amount.c_str());
			item.capa = atof(capa.c_str());
			item.car_model = car_model;
			item.dayMaxHanger = atoi(dayMaxHanger.c_str());
			item.item_code = item_code;
			item.item_group = item_group;
			item.item_name = item_name;
			item.sub_assembly_name = sub_assembly_name;
			item.maxHangerNum = atoi(maxHangerNum.c_str());
			item.max_middle_nonpack = atoi(max_middle_nonpack.c_str());
			item.min_middle_nonpack = atoi(min_middle_nonpack.c_str());
			item.needed_hanger = atoi(needed_hanger.c_str());
			item.pack_load = atoi(pack_load.c_str());
			item.pack_type = pack_type;
			item.type_code = type_code;

			v_items_to_schedule.push_back(item);
		}
		fin.close();
	}
	else {
		log_out << "packing_information file is not opened" << endl;
		throw 6;
	}
}