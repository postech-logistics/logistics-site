#include "heuristics.h"
#include "hanger.h"
#include "operation.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>
#include "item.h"
#include "mix_standard.h"
#include "result_summary.h"
#include <ctime>

using namespace std;

int mixWeight2(vector<c_mix_standard>& mix_standard, c_item& item1, c_item& item2) {
	bool type(item1.type_code == item2.type_code ? true : false); // Comparing type code
	bool pack(item1.pack_type == item2.pack_type ? true : false); // Comparing pack type
	bool name(item1.item_name == item2.item_name ? true : false); // Comparing item name
	bool sub_assembly(item1.sub_assembly_name == item2.sub_assembly_name ? true : false) ; // Comparing item spec name
	bool model(item1.car_model == item2.car_model ? true : false); // Comparing car's model code

	return search_penalty(mix_standard, type, pack, name, sub_assembly, model);
}

double calculateMixCost(vector<c_mix_standard>& mix_standard, vector<c_hanger>& hangerContainer, result_summary &summary) {

	int mixCost = 0;
	int mix_cnt = 0;
	for (int h = 0; h < hangerContainer.size(); h++) {
		if (hangerContainer[h].item_list.size() >= 2) {
			for (int i = 0; i < hangerContainer[h].item_list.size() - 1; i++) {
				for (int j = i + 1; j < hangerContainer[h].item_list.size(); j++) {
					mixCost += mixWeight2(mix_standard, hangerContainer[h].item_list[i], hangerContainer[h].item_list[j]);
				}
			}
			mix_cnt++;
		}
	}
	summary.mix_case = mix_cnt;

	return mixCost;
}

double calculateMaxP(vector<c_hanger>& hangerContainer) {

	int MaxP = 0;

	for (int h = 0; h < hangerContainer.size() - 9; h++) {

		double tempTotalPackingWorkloads = 0;

		for (int j = h; j < h + 10; j++) {
			for (int k = 0; k < hangerContainer[j].item_list.size(); k++) {
				tempTotalPackingWorkloads += hangerContainer[j].item_list[k].pack_load * hangerContainer[j].item_amt[k] / (double)hangerContainer[j].item_list[k].needed_hanger;
			}
		}

		if (tempTotalPackingWorkloads > MaxP) {
			MaxP = tempTotalPackingWorkloads;
		}
	}

	return MaxP;
}

double calculateLoss(vector<c_hanger>& hangerContainer) {
	double lossCost = 0;
	for (int h = 0; h < (int)hangerContainer.size(); h++) {
		lossCost += hangerContainer[h].capacity_percentage / 100;  // to match the unit used in MIP model (while considering the weight value used for the capacity loss)
	}

	return lossCost;
}

double calculateEligible(vector<c_hanger>& hangerContainer) {
	int cost = 0;
	for (int h = 0; h < (int)hangerContainer.size(); h++) {
		for (int i = 0; i < (int)hangerContainer[h].item_list.size(); i++) {
			if (!hangerContainer[h].eligibility_check(hangerContainer[h].item_list[i])) {
				cost++;
			}
		}
	}
	return cost;
}

double calculatePartiallyHungItems(vector<c_hanger>& hangerContainer, vector<c_item>& v_input_check_partial_load) {
	int totalPartiallyHangOrNot = 0;

	for (int i = 0; i < (int)v_input_check_partial_load.size(); i++) {

		double amountOfHungItems = 0;
		for (int h = 0; h < (int)hangerContainer.size(); h++) {
			for (int k = 0; k < hangerContainer[h].item_list.size(); k++) {
				if (hangerContainer[h].item_list[k].item_code == v_input_check_partial_load[i].item_code) {
					amountOfHungItems += hangerContainer[h].item_amt[k] / (double)hangerContainer[h].item_list[k].needed_hanger;
				}
			}
		}

		if (amountOfHungItems != 0 && amountOfHungItems != v_input_check_partial_load[i].amount) {
			totalPartiallyHangOrNot = totalPartiallyHangOrNot + 1;
		}
	}
	return totalPartiallyHangOrNot;
}

double calculateSeparationPenalty(vector<c_hanger>& hangerContainer, vector<c_item>& v_input_check_partial_load) {
	int penaltyForSeparation = 0;

	for (int i = 0; i < (int)v_input_check_partial_load.size(); i++) {
		int lastHangerForItem = -1;
		for (int h = 0; h < (int)hangerContainer.size(); h++) {
			for (int k = 0; k < hangerContainer[h].item_list.size(); k++) {
				if (hangerContainer[h].item_list[k].item_code == v_input_check_partial_load[i].item_code) {
					if (h > 0 && lastHangerForItem != -1 && lastHangerForItem != h - 1) {
						penaltyForSeparation = 9999999999;
						goto Exitloop;
					}
					else {
						lastHangerForItem = h;
					}
					break;
				}
			}
		}
	Exitloop:;
	}
	return penaltyForSeparation;
}

double calculateTotalCost(vector<c_mix_standard>& mix_standard, vector<c_hanger>& hangerContainer, vector<double> &cost_array, c_parameter &param, result_summary &summary, vector<c_item>& v_input_check_partial_load) {//, vector<double>& cnt_result) {
	double c1 = calculateMixCost(mix_standard, hangerContainer, summary);
	double c2 = calculateMaxP(hangerContainer);
	double c3 = calculateLoss(hangerContainer);
	double c4 = calculatePartiallyHungItems(hangerContainer, v_input_check_partial_load);
	double c6 = calculateSeparationPenalty(hangerContainer, v_input_check_partial_load);

	cost_array[0] = c1;
	cost_array[1] = c2;
	cost_array[2] = c3;
	cost_array[3] = 0; //  c4;
	cost_array[3] = c4;
	cost_array[5] = c6;

	return param.mix_weight*c1 + param.maxP_weight*c2 + param.loss_weight*c3 + param.partial_weight*c4 + c6;
}

void readParameters(char * filename, vector<c_parameter> & param)
{
	fstream fin;
	fin.open(filename);
	string temp, w1, w2, w3, w4, w5;
	if (fin.is_open()) {
		getline(fin, temp);
		for (int i = 0; !fin.eof(); i++) {
			w1 = "";
			getline(fin, w1, ',');
			if (w1 == "")
				break;
			getline(fin, w2, ',');
			getline(fin, w3, ',');
			getline(fin, w4);
			c_parameter sample(atof(w1.c_str()), atof(w2.c_str()), atof(w3.c_str()), atoi(w4.c_str()));
			param.push_back(sample);
		}

	}
	else {
		log_out << filename << "cannot be opened" << endl;
		throw - 1;
	}
}

void read_list_of_items_in_stored_best_initial_sequence(char * filename5, vector<string>& temp_list_ot_items_in_stored_best_initial_sequence)
{
	string temp, s_temp_list_ot_items_in_stored_best_initial_sequence;
	ifstream fin;
	fin.open(filename5);
	if (fin.is_open()) {
		getline(fin, temp); // Not including the title
		s_temp_list_ot_items_in_stored_best_initial_sequence = "";
		while (!fin.eof()) {
			getline(fin, s_temp_list_ot_items_in_stored_best_initial_sequence);
			if (s_temp_list_ot_items_in_stored_best_initial_sequence == "")
				break;

			temp_list_ot_items_in_stored_best_initial_sequence.push_back(s_temp_list_ot_items_in_stored_best_initial_sequence);
		}
		fin.close();
	}
	else {
		log_out << "item input file = " << filename5 << " is not opened" << endl;
		throw 2;
	}
}

void initialize_hanger_start_index(vector<pack>& pack_info, int value)
{
	for (int p = 0; p < (int)pack_info.size(); p++) {
		pack_info[p].start_hanger_index = value;
		pack_info[p].total_amount_sum = 0.0;
		pack_info[p].amount_sum = 0.0;
	}
}
int getStartIndex(vector<pack>& pack_info, string pack_type) {
	for (int p = 0; p < (int)pack_info.size(); p++) {
		if (pack_info[p].packType == pack_type) {
			return p;
		}
	}
	log_out << "pack_load " << pack_type << " does not exist in pack_info" << endl;
	throw - 1;
}

int makeSubSequence(vector<pack>& pack_info, vector<c_item>& v_input1, int &v_input_1_start_index, vector<c_hanger>&v_hangers,
	int &start_hanger_index, int min_hanger_count, int max_hanger_count, int item2and3remains) {

	int last_loaded_item_index_load1 = -1;  //Used to skip unnecessary swapping candidates

	int hanger_max_num = min((int)v_hangers.size(), start_hanger_index + max_hanger_count);
	int min_counted_index = start_hanger_index + min_hanger_count;

	for (int j = v_input_1_start_index; j < (int)v_input1.size(); j++) {

		int amt1 = (int)v_input1[j].remained_amount;
		int cap1 = (int)v_input1[j].capa;
		int need_h1 = v_input1[j].needed_hanger;
		bool check = false;
		if (need_h1 == 1) {
			for (int m1 = start_hanger_index; m1 < hanger_max_num; m1++) {

				if (v_hangers[m1].available_group != NOTHING) {

					// Do not allow separated hanging of items with same type
					if (m1 > 0) {
						int itemsWillBeSeparatedlyHung = 0;
						int lastHangerIndexForItem = -1;
						for (int k = 0; k < m1; k++) {
							int itemExistOnHanger = 0;
							for (int l = 0; l < v_hangers[k].item_list.size(); l++) {
								if (v_hangers[k].item_list[l].item_code == v_input1[j].item_code) {
									itemExistOnHanger = 1;
									break;
								}
							}
							if (itemExistOnHanger == 1) {
								lastHangerIndexForItem = k;
							}
							if (itemExistOnHanger == 0 && lastHangerIndexForItem != -1 && lastHangerIndexForItem != m1 - 1) {
								itemsWillBeSeparatedlyHung = 1;
							}
						}
						if (itemsWillBeSeparatedlyHung == 1) {
							break;
						}
					}

					int hanged_amt1 = (int)floor((v_hangers[m1].capacity_percentage / 100)*cap1);
					if (amt1 >= 1. && amt1 <= hanged_amt1) {
						v_hangers[m1].hang(v_input1[j], amt1);
						last_loaded_item_index_load1 = j;  // Used to skip unnecessary swapping candidates
						amt1 = 0;
						start_hanger_index = m1;
						check = true;
						break;
					}
					else if (hanged_amt1 >= 1.0) {

						if (amt1 == 0) {
							check = true;
							break;
						}

						v_hangers[m1].hang(v_input1[j], hanged_amt1);
						last_loaded_item_index_load1 = j;  // Used to skip unnecessary swapping candidates
						amt1 -= hanged_amt1;
						start_hanger_index++;
					}
				}
			} // for m1

			if (check == true) {
				v_input_1_start_index = j + 1;
				v_input1[j].remained_amount = 0.0;

				if (item2and3remains == 1) {
					return last_loaded_item_index_load1;  // Used to skip unnecessary swapping candidates
				}
			}
		}
		else if (need_h1 == 2) { // If number of required hangers = 2
			for (int m1 = start_hanger_index; m1 < hanger_max_num - 1; m1++) {

				if (v_hangers[m1].available_group != NOTHING&&v_hangers[m1 + 1].available_group != NOTHING
					&& v_hangers[m1].capacity_percentage == v_hangers[m1 + 1].capacity_percentage) {

					// Do not allow separated hanging of items with same type
					if (m1 > 0) {
						int itemsWillBeSeparatedlyHung = 0;
						int lastHangerIndexForItem = -1;
						for (int k = 0; k < m1; k++) {
							int itemExistOnHanger = 0;
							for (int l = 0; l < v_hangers[k].item_list.size(); l++) {
								if (v_hangers[k].item_list[l].item_code == v_input1[j].item_code) {
									itemExistOnHanger = 1;
									break;
								}
							}
							if (itemExistOnHanger == 1) {
								lastHangerIndexForItem = k;
							}
							if (itemExistOnHanger == 0 && lastHangerIndexForItem != -1 && lastHangerIndexForItem != m1 - 1) {
								itemsWillBeSeparatedlyHung = 1;
							}
						}
						if (itemsWillBeSeparatedlyHung == 1) {
							break;
						}
					}

					int hanged_amt1 = min((int)floor((v_hangers[m1].capacity_percentage / 100)*cap1), (int)floor((v_hangers[m1 + 1].capacity_percentage / 100)*cap1));
					if (amt1 >= 1. && amt1 <= hanged_amt1) {
						v_hangers[m1].hang(v_input1[j], amt1);
						v_hangers[m1 + 1].hang(v_input1[j], amt1);
						last_loaded_item_index_load1 = j;  // Used to skip unnecessary swapping candidates
						amt1 = 0;
						start_hanger_index = m1;
						check = true;
						break;
					}
					else if (hanged_amt1 >= 1.0) {

						// If there is no remaining item, do not hang any of this item
						if (amt1 == 0) {
							check = true;
							break;
						}

						v_hangers[m1].hang(v_input1[j], hanged_amt1);
						v_hangers[m1 + 1].hang(v_input1[j], hanged_amt1);
						last_loaded_item_index_load1 = j;  // Used to skip unnecessary swapping candidates
						amt1 -= hanged_amt1;
						start_hanger_index = start_hanger_index + need_h1;
						//This code is determining the starting hanger index for hanging next items (it is only executed once among 2 hangers if need_h1=2)
					}
				}
			} // for m1

			if (check == true) {
				v_input_1_start_index = j + 1;
				v_input1[j].remained_amount = 0.0;
				if (item2and3remains == 1) {
					return last_loaded_item_index_load1;  // Used to skip unnecessary swapping candidates
				}
			}
		} // if
	} // for j

	return last_loaded_item_index_load1;  // Used to skip unnecessary swapping candidates
}
// Find index that is not INNER_ONLY or NON_PACK.
int get_change_group_index(vector<c_hanger>& v_hangers, int start_index)
{
	for (int i = start_index; i < (int)v_hangers.size(); i++) {
		if (v_hangers[i].available_group != INNER_ONLY && v_hangers[i].available_group != NON_PACK)
			return i;
	}
	return (int)v_hangers.size();
}

void initialize_remained_amount(vector<c_item>& v_input_temp)
{
	for (int i = 0; i < (int)v_input_temp.size(); i++)
		v_input_temp[i].remained_amount = v_input_temp[i].amount;
}

int makeSeqeunce3(vector<pack>& pack_info, vector<c_item>& v_input1, vector<c_item>& v_input_2_3, vector<c_hanger>& v_hangers, int mode, int last_loaded_item_index) {
	int h = 0;
	initialize_hanger_start_index(pack_info, -1);

	initialize_remained_amount(v_input1);
	initialize_remained_amount(v_input_2_3);

	if (mode == 0) {
		h = 0; // Input hangers again from the beginning
		setHangerClear(v_hangers);
	}
	else {
		while (v_hangers[h].capacity_percentage < 100) h++;
		if (h >= v_hangers.size()) {
			log_out << "Inputted hanger is fully utilized. Remaining items are stored in the unscheduled_list" << endl;
			throw 7;
		}
	}

	int item2and3remains = 1;
	int last_loaded_item_index_load1 = -1;  //Used to skip unnecessary swapping candidates

	int v_input_1_start_index = 0;
	for (int i = 0; i < v_input_2_3.size(); i++) {

		last_loaded_item_index = i;  // Used to skip unnecessary swapping candidates

		int lastHangerIndexOfItem = -1;  // Do not allow separated hanging of items with same type

		int load = v_input_2_3[i].pack_load;
		int ptype_sindex = getStartIndex(pack_info, v_input_2_3[i].pack_type);
		int amt = (int)v_input_2_3[i].remained_amount;
		int cap = (int)v_input_2_3[i].capa;
		int need_h = v_input_2_3[i].needed_hanger;
		if (need_h == 1) {
			for (int m = h; m < (int)v_hangers.size(); m++) {
				if (m > 0) {
					int itemsWillBeSeparatedlyHung = 0;
					int lastHangerIndexForItem2 = -1;
					for (int k = 0; k < m; k++) {
						int itemExistOnHanger = 0;
						for (int l = 0; l < v_hangers[k].item_list.size(); l++) {
							if (v_hangers[k].item_list[l].item_code == v_input_2_3[i].item_code) {
								itemExistOnHanger = 1;
								break;
							}
						}
						if (itemExistOnHanger == 1) {
							lastHangerIndexForItem2 = k;
						}
						if (itemExistOnHanger == 0 && lastHangerIndexForItem2 != -1 && lastHangerIndexForItem2 != m - 1) {
							itemsWillBeSeparatedlyHung = 1;
						}
					}
					if (itemsWillBeSeparatedlyHung == 1) {
						break;
					}
				}

				if (v_hangers[m].available_group == INNER_ONLY || v_hangers[m].available_group == NON_PACK) {
					int end_count = get_change_group_index(v_hangers, m + 1) - m;
					int next_hanger_num = m;

					last_loaded_item_index_load1 = makeSubSequence(pack_info, v_input1, v_input_1_start_index, v_hangers, next_hanger_num, end_count, end_count, item2and3remains);
					if (last_loaded_item_index_load1 != -1) {
						for (int j = 0; j < v_input_2_3.size(); j++) {
							if (v_input_2_3[j].item_name == v_input1[last_loaded_item_index_load1].item_name) {
								if (j > last_loaded_item_index) {
									last_loaded_item_index = j;  //Used to skip unnecessary swapping candidates
									break;
								}
							}
						}
					}

					if (next_hanger_num > m) {
						m = next_hanger_num - 1;			// Considering that the index is increased by 1 in the for loop
						pack_info[ptype_sindex].start_hanger_index = -1;			// Initializing once more
					}
					h = m;
				}
				// Check whether it needs to be included, then stored in v_input1
				else if (pack_info[ptype_sindex].start_hanger_index != -1 && m - pack_info[ptype_sindex].start_hanger_index >= pack_info[ptype_sindex].maxHangerNum) {
					int next_hanger_num = m;

					last_loaded_item_index_load1 = makeSubSequence(pack_info, v_input1, v_input_1_start_index, v_hangers, next_hanger_num,
						pack_info[ptype_sindex].min_middle_nonpack, pack_info[ptype_sindex].max_middle_nonpack, item2and3remains);
					if (last_loaded_item_index_load1 != -1) {
						for (int j = 0; j < v_input_2_3.size(); j++) {
							if (v_input_2_3[j].item_name == v_input1[last_loaded_item_index_load1].item_name) {
								if (j > last_loaded_item_index) {
									last_loaded_item_index = j;  //Used to skip unnecessary swapping candidates
									break;
								}
							}
						}
					}

					if (next_hanger_num > m) {
						m = next_hanger_num - 1;			// Considering that the index is increased by 1 in the for loop
						pack_info[ptype_sindex].start_hanger_index = -1;			// Initializing once more
					}
					h = m;
					pack_info[ptype_sindex].start_hanger_index = m;
				}
				else {
					if (v_hangers[m].available_group != NOTHING) {
						int hanged_amt = (int)floor((v_hangers[m].capacity_percentage / 100)*cap);
						if (amt >= 1. && amt <= hanged_amt) {
							if (lastHangerIndexOfItem != -1 && lastHangerIndexOfItem != m - need_h) {
								break;
							}
							else {
								lastHangerIndexOfItem = m;
							}

							v_hangers[m].hang(v_input_2_3[i], amt);

							// Updating remaining amount of item with packing workload = 1, which are also in v_input1 (not only updating the ones in in v_input_2_3)
							for (int j = 0; j < v_input1.size(); j++) {
								if (v_input_2_3[i].item_code == v_input1[j].item_code)
									v_input1[j].remained_amount -= amt;
							}
							amt = 0;
							h = m;
							if (pack_info[ptype_sindex].start_hanger_index == -1)
								pack_info[ptype_sindex].start_hanger_index = m;
							break;
						}
						else if (hanged_amt >= 1.0) {

							if (lastHangerIndexOfItem != -1 && lastHangerIndexOfItem != m - need_h) {
								break;
							}
							else {
								lastHangerIndexOfItem = m;
							}

							v_hangers[m].hang(v_input_2_3[i], hanged_amt);

							// Updating remaining amount of item with packing workload = 1, which are also in v_input1 (not only updating the ones in in v_input_2_3)
							for (int j = 0; j < v_input1.size(); j++) {
								if (v_input_2_3[i].item_code == v_input1[j].item_code)
									v_input1[j].remained_amount -= hanged_amt;
							}
							amt -= hanged_amt;
							if (pack_info[ptype_sindex].start_hanger_index == -1)
								pack_info[ptype_sindex].start_hanger_index = m;
						}
					}

					// To avoid hanging items separatedly
					else {
						if (lastHangerIndexOfItem != -1)
							break;
					}
				}
			}
		}
		else if (need_h == 2) { // If required number of hangers = 2

			for (int m = h; m < (int)v_hangers.size() - 1; m++) {

				// Do not allow separated hanging of items with same type
				if (m > 0) {
					int itemsWillBeSeparatedlyHung = 0;
					int lastHangerIndexForItem2 = -1;
					for (int k = 0; k < m; k++) {
						int itemExistOnHanger = 0;
						for (int l = 0; l < v_hangers[k].item_list.size(); l++) {
							if (v_hangers[k].item_list[l].item_code == v_input_2_3[i].item_code) {
								itemExistOnHanger = 1;
								break;
							}
						}
						if (itemExistOnHanger == 1) {
							lastHangerIndexForItem2 = k;
						}
						if (itemExistOnHanger == 0 && lastHangerIndexForItem2 != -1 && lastHangerIndexForItem2 != m - 1) {
							itemsWillBeSeparatedlyHung = 1;
						}
					}
					if (itemsWillBeSeparatedlyHung == 1) {
						break;
					}
				}

				if (v_hangers[m].available_group == INNER_ONLY || v_hangers[m].available_group == NON_PACK || v_hangers[m + 1].available_group == INNER_ONLY || v_hangers[m + 1].available_group == NON_PACK) {

					int end_count = get_change_group_index(v_hangers, m + 1) - m;
					int next_hanger_num = m;

					last_loaded_item_index_load1 = makeSubSequence(pack_info, v_input1, v_input_1_start_index, v_hangers, next_hanger_num, end_count, end_count, item2and3remains);
					if (last_loaded_item_index_load1 != -1) {
						for (int j = 0; j < v_input_2_3.size(); j++) {
							if (v_input_2_3[j].item_name == v_input1[last_loaded_item_index_load1].item_name) {
								if (j > last_loaded_item_index) {
									last_loaded_item_index = j;  //Used to skip unnecessary swapping candidates
									break;
								}
							}
						}
					}

					if (next_hanger_num > m) {
						m = next_hanger_num - 1;			// Considering that the index is increased by 1 in the for loop
						pack_info[ptype_sindex].start_hanger_index = -1;			// Initializing once more
					}
					h = m;
				}
				// Check whether it needs to be included, then stored in v_input1
				else if (pack_info[ptype_sindex].start_hanger_index != -1 && m - pack_info[ptype_sindex].start_hanger_index >= pack_info[ptype_sindex].maxHangerNum) {
					int next_hanger_num = m;

					last_loaded_item_index_load1 = makeSubSequence(pack_info, v_input1, v_input_1_start_index, v_hangers, next_hanger_num,
						pack_info[ptype_sindex].min_middle_nonpack, pack_info[ptype_sindex].max_middle_nonpack, item2and3remains);
					if (last_loaded_item_index_load1 != -1) {
						for (int j = 0; j < v_input_2_3.size(); j++) {
							if (v_input_2_3[j].item_name == v_input1[last_loaded_item_index_load1].item_name) {
								if (j > last_loaded_item_index) {
									last_loaded_item_index = j;  //Used to skip unnecessary swapping candidates
									break;
								}
							}
						}
					}

					if (next_hanger_num > m) {
						m = next_hanger_num - 1;			// Considering that the index is increased by 1 in the for loop
						pack_info[ptype_sindex].start_hanger_index = -1;			// Initializing once more
					}
					h = m;
					pack_info[ptype_sindex].start_hanger_index = m;
				}
				else {
					if (v_hangers[m].available_group != NOTHING&&v_hangers[m + 1].available_group != NOTHING
						&& v_hangers[m].capacity_percentage == v_hangers[m + 1].capacity_percentage) {
						int hanged_amt = min((int)floor((v_hangers[m].capacity_percentage / 100)*cap), (int)floor((v_hangers[m + 1].capacity_percentage / 100)*cap));

						if (amt >= 1. && amt <= hanged_amt) {

							// Do not allow separated hanging of items with same type
							if (lastHangerIndexOfItem != -1 && lastHangerIndexOfItem != m - need_h) {
								break;
							}
							else {
								lastHangerIndexOfItem = m;
							}

							v_hangers[m].hang(v_input_2_3[i], amt);
							v_hangers[m + 1].hang(v_input_2_3[i], amt);

							// Updating remaining amount of item with packing workload = 1, which are also in v_input1 (not only updating the ones in in v_input_2_3)
							for (int j = 0; j < v_input1.size(); j++) {
								if (v_input_2_3[i].item_code == v_input1[j].item_code)
									v_input1[j].remained_amount -= amt;
							}
							amt = 0;
							h = m;
							if (pack_info[ptype_sindex].start_hanger_index == -1)
								pack_info[ptype_sindex].start_hanger_index = m;
							break;
						}
						else if (hanged_amt >= 1.0) {

							// Do not allow separated hanging of items with same type
							if (lastHangerIndexOfItem != -1 && lastHangerIndexOfItem != m - need_h) {
								break;
							}
							else {
								lastHangerIndexOfItem = m;
							}

							v_hangers[m].hang(v_input_2_3[i], hanged_amt);
							v_hangers[m + 1].hang(v_input_2_3[i], hanged_amt);

							// Updating remaining amount of item with packing workload = 1, which are also in v_input1 (not only updating the ones in in v_input_2_3)
							for (int j = 0; j < v_input1.size(); j++) {
								if (v_input_2_3[i].item_code == v_input1[j].item_code)
									v_input1[j].remained_amount -= hanged_amt;
							}

							amt -= hanged_amt;

							if (pack_info[ptype_sindex].start_hanger_index == -1)
								pack_info[ptype_sindex].start_hanger_index = m;
						}
					}
				}
			}
		}
		else {
			log_out << "The number of required hangers is not equal to 1 or 2." << endl;
			throw 4;
		}
		if (h >(int)v_hangers.size()) {
			log_out << "The number of hangers is not enough. " << endl;
			log_out << "The remaining number of items: " << v_input_2_3.size() - i << endl;
			break;
		}
	}

	item2and3remains = 0;

	if (v_input_1_start_index < (int)v_input1.size()) {

		last_loaded_item_index_load1 = makeSubSequence(pack_info, v_input1, v_input_1_start_index, v_hangers, h, (int)v_hangers.size(), (int)v_hangers.size(), item2and3remains);  //Used to skip unnecessary swapping candidates
		if (last_loaded_item_index_load1 != -1) {
			for (int i = 0; i < v_input_2_3.size(); i++) {
				if (v_input_2_3[i].item_name == v_input1[last_loaded_item_index_load1].item_name) {
					if (i > last_loaded_item_index) {
						last_loaded_item_index = i;  //Used to skip unnecessary swapping candidates
						break;
					}
				}
			}
		}
	}

	if (h < (int)v_hangers.size())
		v_hangers[h].last = true;

	return last_loaded_item_index;  //Used to skip unnecessary swapping candidates
}

int find_pack_index(vector<pack> &pack_info, string pack_type) {
	for (int p = 0; p < (int)pack_info.size(); p++) {
		if (pack_info[p].packType == pack_type)
			return p;
	}
	if (pack_type == "")
		return (int)pack_info.size() - 1;
	log_out << "Packing information is not found" << endl;
	throw 10;
}

void dividInputList(vector<pack> & pack_info, vector<c_item> & original_input, vector<c_item>& input1, vector<c_item>&input2, int day_max_hanger_num) {
	vector<double> amount_sum((int)pack_info.size(), 0.0);
	vector<c_item> v_items_unscheduled;
	double total_amount_sum = 0.0;
	int pack_index = 0;

	for (int i = 0; i < (int)original_input.size(); i++) {
		pack_index = find_pack_index(pack_info, original_input[i].pack_type);
		double min_hanger_num = original_input[i].amount / original_input[i].capa;

		// If the list of packed items is still smaller than the maximum number of working hangers per day, they are stored into the input list
		amount_sum[pack_index] += min_hanger_num;
		total_amount_sum += min_hanger_num;
		if (original_input[i].pack_load == 1) {
			input1.push_back(original_input[i]);
			input2.push_back(original_input[i]);
		}
		else input2.push_back(original_input[i]);
	}
	for (int i = 0; i < (int)input1.size(); i++)
		input1[i].remained_amount = input1[i].amount;
	for (int i = 0; i < (int)input2.size(); i++)
		input2[i].remained_amount = input2[i].amount;
	original_input = v_items_unscheduled;
}

void simple_heuristic(vector<c_item>& v_input, vector<c_hanger>& v_hangers, vector<c_parameter> &param, vector<pack> &pack_info, vector<c_mix_standard>& mix_standard, result_summary &summary, int algorithm_type)
{
	double best_cost, cur_cost;
	vector<c_hanger> v_hangers_org, best_v_hangers, v_hanger_copy, best_case;
	vector<c_item> v_input_copy, best_v_input, v_input1, v_input2_3, v_input1_copy, v_input2_3_copy;
	vector<c_item> best_v_input1, best_v_input2_3;
	vector<vector<double>> cost_result;

	double best_non_tabu_cost;
	vector<c_hanger> best_non_tabu_v_hangers, cur_v_hangers;  // cur_v_hangers is used to store the current basic v_hangers in the current iteration and check whether any swapping movement can be skipped or not
	double worse_percentage_solution_accepted_with_prob_point_five = 0.35;  // Used for selecting worse solution with Boltzmann/SA probability

	srand(6837);
	v_hangers_org = v_hangers;  // v_hangers_org must be kept empty in the whole code(for reseting the hanger contents every time a new schedule is created)

	//This code is used to skip some swapping candidates, which will not improve the solution
	//Given a certain solution, we store the last loaded item index. If the first swap index (i) is larger than the stored index, skip swapping the candidate
	//Every time any (worse or same good) solution is obtained, update the last loaded item index
	//Every time a better solution is obtained (which changes the structure of the basic solution for the search), the stored index is reset
	int last_loaded_item_index = -1;

	clock_t begin = clock();

	vector<double> cost_array(6);
	vector<double> best_cost_array(6);
	vector<double> best_non_tabu_cost_array(6);

	vector<c_item> v_input_check_partial_load;
	for (int i = 0; i < (int)v_input.size(); i++) {
		v_input_check_partial_load.push_back(v_input[i]);
	}

	vector<c_item> v_input_initial;
	for (int i = 0; i < (int)v_input.size(); i++) {
		v_input_initial.push_back(v_input[i]);
	}

	vector<c_item> v_input_initial_TEMP;
	for (int i = 0; i < (int)v_input.size(); i++) {
		v_input_initial_TEMP.push_back(v_input[i]);
	}

	// Selecting an arbitrary initial item, then add other items with the least mixing cost (with last hung item)

	// Multiple initial solutions may be considered, therefore store the best solution using each initial solution
	double all_initial_best_cost;
	all_initial_best_cost = 999999999;
	result_summary global_best_summary;
	result_summary best_non_tabu_summary;
	result_summary all_initial_best_summary;
	vector<c_hanger> all_initial_best_v_hangers;
	vector<c_item> all_initial_best_v_input1, all_initial_best_v_input2_3;


	// Sort the item order in v_input from the one with the least objective value (calculated after hanging all possible items to the hangers based on the generated sequence)
	//int initial_item_index = 0;
	int initial_item_index = rand() % (int)v_input.size();  // To select a random initial sequence (not the best one)

	vector<double> objvalue_for_each_initial_starting_items;
	double best_objvalue_for_each_initial_starting_items = 999999.0;
	vector<int> best_initial_starting_item_index;
	vector<int> v_selected_random_no_for_initial_sequence;  // For storing selected random numbers for generating the initial solution
	vector<int> best_v_selected_random_no_for_initial_sequence;
	vector<int> best_objvalue_for_same_initial_item_index_v_selected_random_no_for_initial_sequence;

	while (initial_item_index != (int)v_input.size()) {

		int random_reset_counter = 0;
		double best_objvalue_for_same_initial_item_index = 999999.0;

		while (random_reset_counter < 1) {

			v_selected_random_no_for_initial_sequence.clear();

			// Calculate the objective value after loading all possible items for each generated sequence (store the values in a list)
			// Then after that, create another list that contains the sorted initial items based on the ones with least objective value
			int v_input_size = (int)v_input.size();
			v_input.clear();
			v_input.push_back(v_input_initial_TEMP[initial_item_index]);
			v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + initial_item_index);

			while ((int)v_input.size() != v_input_size) {

				// Only selecting the next item that has smallest mixed cost with previously hung item (with randomness, considering many items has same smallest mixed cost)
				int least_mix_cost = 999999999;
				int selected_index = -1;
				int smallest_total_next_mix_cost = 999999999;
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) < least_mix_cost) {
						least_mix_cost = mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]);
					}
				}
				// Count number of candidates with the least_mix_cost, then select a random item to be the next hung item, without considering the total_next_mix_cost with other unhung items
				int no_of_candidates_with_least_mix_cost = 0;
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
						no_of_candidates_with_least_mix_cost = no_of_candidates_with_least_mix_cost + 1;
					}
				}
				int rand_number = rand() % no_of_candidates_with_least_mix_cost;

				v_selected_random_no_for_initial_sequence.push_back(rand_number);

				int candidate_index_counter = 0;
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
						if (candidate_index_counter == rand_number) {
							selected_index = h;
							break;
						}
						else {
							candidate_index_counter = candidate_index_counter + 1;
						}
					}
				}

				v_input.push_back(v_input_initial_TEMP[selected_index]);
				v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + selected_index);
			}

			for (int i = 0; i < (int)v_input.size(); i++) {
				v_input_initial_TEMP.push_back(v_input_initial[i]);
			}

			v_input1.clear();
			v_input2_3.clear();

			dividInputList(pack_info, v_input, v_input1, v_input2_3, (int)v_hangers.size());

			v_hanger_copy = v_hangers_org; // v_hangers_org must be kept empty in the whole code(for reseting the hanger contents every time a new schedule is created)

			last_loaded_item_index = makeSeqeunce3(pack_info, v_input1, v_input2_3, v_hanger_copy, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates
			cur_cost = calculateTotalCost(mix_standard, v_hanger_copy, cost_array, param[0], summary, v_input_check_partial_load);

			if (cur_cost < best_objvalue_for_same_initial_item_index) {
				best_objvalue_for_same_initial_item_index = cur_cost;
				best_objvalue_for_same_initial_item_index_v_selected_random_no_for_initial_sequence.clear();
				for (int i = 0; i < (int)v_selected_random_no_for_initial_sequence.size(); i++) {
					best_objvalue_for_same_initial_item_index_v_selected_random_no_for_initial_sequence.push_back(v_selected_random_no_for_initial_sequence[i]);
				}
			}

			for (int i = 0; i < (int)v_input_initial.size(); i++) {
				v_input.push_back(v_input_initial[i]);
			}

			random_reset_counter = random_reset_counter + 1;
		}

		if (best_objvalue_for_same_initial_item_index < best_objvalue_for_each_initial_starting_items) {
			best_objvalue_for_each_initial_starting_items = best_objvalue_for_same_initial_item_index;
			best_v_selected_random_no_for_initial_sequence.clear();
			for (int i = 0; i < (int)best_objvalue_for_same_initial_item_index_v_selected_random_no_for_initial_sequence.size(); i++) {
				best_v_selected_random_no_for_initial_sequence.push_back(best_objvalue_for_same_initial_item_index_v_selected_random_no_for_initial_sequence[i]);
			}
		}

		if (objvalue_for_each_initial_starting_items.size() == 0) {
			objvalue_for_each_initial_starting_items.push_back(best_objvalue_for_same_initial_item_index);
			best_initial_starting_item_index.push_back(initial_item_index);
		}
		else {
			int best_insertion_position = -1;  // last position in the list
			for (int i = (int)objvalue_for_each_initial_starting_items.size() - 1; i >= 0; i--) {
				if (best_objvalue_for_same_initial_item_index <= objvalue_for_each_initial_starting_items[i]) {
					best_insertion_position = i;
				}
			}
			if (best_insertion_position == -1) {
				objvalue_for_each_initial_starting_items.push_back(best_objvalue_for_same_initial_item_index);
				best_initial_starting_item_index.push_back(initial_item_index);
			}
			else {
				objvalue_for_each_initial_starting_items.insert(objvalue_for_each_initial_starting_items.begin() + best_insertion_position, best_objvalue_for_same_initial_item_index);
				best_initial_starting_item_index.insert(best_initial_starting_item_index.begin() + best_insertion_position, initial_item_index);
			}
		}

		initial_item_index = initial_item_index + 1;

		break;   // To select a random initial sequence (not the best one)
	}

	initial_item_index = 0;
	int v_input_size = (int)v_input.size();
	v_input.clear();
	v_input.push_back(v_input_initial_TEMP[best_initial_starting_item_index[initial_item_index]]);
	v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + best_initial_starting_item_index[initial_item_index]);

	while ((int)v_input.size() != v_input_size) {

		// Only selecting the next item that has smallest mixed cost with previously hung item (with randomness, considering many items has same smallest mixed cost)
		int least_mix_cost = 999999999;
		int selected_index = -1;
		int smallest_total_next_mix_cost = 999999999;
		for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
			if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) < least_mix_cost) {
				least_mix_cost = mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]);
			}
		}

		// Count number of candidates with the least_mix_cost, then select a random item to be the next hung item, without considering the total_next_mix_cost with other unhung items
		int no_of_candidates_with_least_mix_cost = 0;
		for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
			if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
				no_of_candidates_with_least_mix_cost = no_of_candidates_with_least_mix_cost + 1;
			}
		}
		int rand_number = best_v_selected_random_no_for_initial_sequence[(int)v_input.size() - 1];

		int candidate_index_counter = 0;
		for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
			if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
				if (candidate_index_counter == rand_number) {
					selected_index = h;
					break;
				}
				else {
					candidate_index_counter = candidate_index_counter + 1;
				}
			}
		}

		v_input.push_back(v_input_initial_TEMP[selected_index]);
		v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + selected_index);
	}

	for (int i = 0; i < (int)v_input.size(); i++) {
		v_input_initial_TEMP.push_back(v_input_initial[i]);
	}

	v_input1.clear();
	v_input2_3.clear();

	v_hangers = v_hangers_org; // for reseting the hanger contents every time a new schedule is created

	dividInputList(pack_info, v_input, v_input1, v_input2_3, (int)v_hangers.size());

	clock_t makeSeqeunce3_begin = clock();

	last_loaded_item_index = makeSeqeunce3(pack_info, v_input1, v_input2_3, v_hangers, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates
	last_loaded_item_index = -1;  //This value must be updated only during the search with indices i and j

	clock_t makeSeqeunce3_end = clock();
	double makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

	//Used to store the required computational time to execute makeSeqeunce3 procedure
	vector<double> makeSeqeunce3_computationaltime;
	makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

	//initialize
	int count = 1; cost_array[4] = count;

	cost_array[5] = count;

	bool improve_check = true;

	clock_t calculateTotalCost_begin = clock();

	// v_hangers_org must be kept empty in the whole code (for reseting the hanger contents every time a new schedule is created)
	best_cost = calculateTotalCost(mix_standard, v_hangers, cost_array, param[0], summary, v_input_check_partial_load);

	clock_t calculateTotalCost_end = clock();
	double calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

	//Used to store the required computational time to execute makeSeqeunce3 procedure
	vector<double> calculateTotalCost_computationaltime;
	calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);

	summary.mixCost = cost_array[0];
	summary.maxP = cost_array[1];
	summary.capacity_loss = cost_array[2];
	summary.partiallyHungItems = cost_array[3];
	summary.separationPenalty = cost_array[5];
	summary.mixCost_weight = param[0].mix_weight*cost_array[0];
	summary.maxP_weight = param[0].maxP_weight*cost_array[1];
	summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
	summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
	summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

	best_v_input1 = v_input1;
	best_v_input2_3 = v_input2_3;
	// v_hangers_org must be kept empty in the whole code (for reseting the hanger contents every time a new schedule is created)
	best_v_hangers = v_hangers;
	cur_v_hangers = v_hangers;  // cur_v_hangers is used to store the current basic v_hangers in the current iteration and check whether any swapping movement can be skipped or not
	best_cost_array = cost_array;
	cost_result.push_back(cost_array);

	// Tabu Search
	vector<c_item> global_best_v_input1, global_best_v_input2_3;
	vector<c_hanger> global_best_v_hangers;
	double global_best_cost;
	vector<double> global_best_cost_array(6);

	global_best_cost = best_cost;  // Initialization

	global_best_v_input1 = v_input1;
	global_best_v_input2_3 = v_input2_3;
	global_best_v_hangers = v_hangers;
	global_best_cost_array = cost_array;

	all_initial_best_v_input1 = v_input1;
	all_initial_best_v_input2_3 = v_input2_3;
	all_initial_best_v_hangers = v_hangers;
	all_initial_best_summary = summary;
	all_initial_best_cost = best_cost;

	int global_count = 0;

	// Tabu Search
	vector<c_item> beforeSwapSequencedItemGroups2_3, beforeSwapSequencedItemGroups1, bestSequenceForWholeProblem2_3, bestSequenceForWholeProblem1;
	vector<double> consecutiveBestSolutionsOfWholeProblem;
	vector<vector<string>> tabuList;
	vector<int> tabuListAmount;

	// Initialization
	int totalTimeLimit = 300;
	int allowedSameConsecutiveObjectiveValuesOfWholeProblem = 20;
	int currentNumberOfSameConsecutiveObjectiveValuesOfWholeProblem = 0;

	int numberOfItems = 0;
	int upperPart = 1;
	int lowerPart = 1;
	int tabuListSizePercent = 0.25;
	int tabuListSize = -1;  // Initialization
	int needToStop = 0;
	int iteration = 0;

	switch (algorithm_type) {
	case 1:

		// Tabu Search

		while (true) {

			double best_of_best_cost_current_initial = best_cost;  // If the best_cost value for current initial solution is not changed for several iterations, continue to the next initial solution
			int no_of_iteration_unchanged_bestcost_in_current_initial = -1;

			// Used for selecting worse solution with Boltzmann/SA probability
			double initial_temperature_SA = -1 * worse_percentage_solution_accepted_with_prob_point_five * best_cost / -0.30103;  // -0.30103 = Log(0.5)
			double temperature_cooling_rate = 0.8;  // c value in Ropke and Pisinger (2006)
			double temperature = initial_temperature_SA;

			clock_t end = clock();
			double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
			if (elapsed_secs > totalTimeLimit) {
				goto Exitloop3;
			}

			bool check1 = false;
			bool check2 = false;
			improve_check = true;
			while (improve_check) {
				improve_check = false;

				if (v_input2_3.size() <= 1) {  // There is no pair to swap
					break;
				}

				v_input1_copy = best_v_input1;
				v_input2_3_copy = best_v_input2_3;

				int new_best_in_this_iteration = 0;
				vector<c_item> best_non_tabu_v_input1, best_non_tabu_v_input2_3;  // Reset the contents of best non tabu item lists
				best_non_tabu_v_input1.clear();
				best_non_tabu_v_input2_3.clear();

				for (int i = 0; i < v_input2_3_copy.size() - 1; i++) {
					for (int j = i + 1; j < v_input2_3_copy.size(); j++) {

						clock_t end = clock();
						double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

						if (elapsed_secs > totalTimeLimit) {
							goto Exitloop1;
						}

						if (i > last_loaded_item_index && last_loaded_item_index != -1) {
							goto ExitCurrentSearch1;  //Used to skip unnecessary swapping candidates
						}

						// Iteratively reduce the tabu list size as the remaining time decreases (finally tabu list size = 0, and TS = 2-Opt)
						double remainingTimePercent = (totalTimeLimit - elapsed_secs) / totalTimeLimit;
						tabuListSizePercent = tabuListSizePercent * remainingTimePercent;

						// Combination = n!/(n-r)!r! = n*(n-1)*(n-2)!/(n-2)!2 = n*(n-1)/2 
						// Use combination intead of permutation, because selecting any pair is same even the items are placed in any different positions in the sequence
						int n = v_input2_3.size();
						tabuListSize = n*(n - 1) / 2 * tabuListSizePercent;  // tabuListSizePercent * the number of item combinations

						//Do not perform search if items type i and j:
						//1.Have same packing load
						//2.Have same characteristics which affects the mixing costs
						//3.Require same number of hangers (considering total number of items, possible number of hung items in a hanger, and required number of hangers per item
						if (v_input2_3_copy[i].pack_load == v_input2_3_copy[j].pack_load
							&& v_input2_3_copy[i].type_code == v_input2_3_copy[j].type_code && v_input2_3_copy[i].pack_type == v_input2_3_copy[j].pack_type
							&& v_input2_3_copy[i].item_name == v_input2_3_copy[j].item_name && v_input2_3_copy[i].sub_assembly_name == v_input2_3_copy[j].sub_assembly_name
							&& v_input2_3_copy[i].car_model == v_input2_3_copy[j].car_model
							&& v_input2_3_copy[i].amount / v_input2_3_copy[i].capa * v_input2_3_copy[i].needed_hanger == v_input2_3_copy[j].amount / v_input2_3_copy[j].capa * v_input2_3_copy[j].needed_hanger)
							continue;

						int sameTabuPairExist = 0;
						int tabuListIndex = -1;

						for (int k = 0; k < tabuList.size(); k++) {
							if (tabuList[k][0] == v_input2_3_copy[i].item_code && tabuList[k][1] == v_input2_3_copy[j].item_code ||
								tabuList[k][0] == v_input2_3_copy[j].item_code && tabuList[k][1] == v_input2_3_copy[i].item_code) {
								sameTabuPairExist = 1;
								tabuListIndex = k;
								break;
							}
						}

						cost_array[4] = 0;

						v_hanger_copy = v_hangers_org; // v_hangers_org must be kept empty in the whole code(for reseting the hanger contents every time a new schedule is created)

					    //Swap same pair of items in v_input1 in order to assure continuous hanging of same items in v_input2_3 and v_input1
					    //(When the used set is changed from v_input2_3 to v_input1 due to the hanger's eligibility)
						int item1_index_v_input1_copy = -1;
						int item2_index_v_input1_copy = -1;
						for (int k = 0; k < v_input1_copy.size(); k++) {
							if (v_input1_copy[k].item_code == v_input2_3_copy[i].item_code) {
								item1_index_v_input1_copy = k;
							}
							if (v_input1_copy[k].item_code == v_input2_3_copy[j].item_code) {
								item2_index_v_input1_copy = k;
							}
						}
						if (item1_index_v_input1_copy != -1 && item2_index_v_input1_copy != -1) {
							//If both items exist in v_input1_copy, swap their positions
							swap(v_input1_copy[item1_index_v_input1_copy], v_input1_copy[item2_index_v_input1_copy]);
						}
						else if (item1_index_v_input1_copy != -1 && item2_index_v_input1_copy == -1) {
							//The i-th item in v_input2_3_copy exists in v_input1, while the j-th item in v_input2_3_copy doesn't exist in v_input1
							//For example: given v_input2_3_copy = {1A, 2A, 1B, 1C, 2B, 1D} and v_input1_copy = {1A, 1B, 1C, 1D}
							//If 1A and 2B is exchanged in v_input2_3_copy, then 1A must be moved after 1C in v_input1_copy 
							//New sequences: v_input2_3_copy = {2B*, 2A, 1B, 1C, 1A*, 1D} and v_input1_copy = {1B, 1C, 1A*, 1D}
							string item_code_pack1_before_item2_in_v_input2_3_copy = "";
							for (int k = i; k < j; k++) {
								if (v_input2_3_copy[k].pack_load == 1) {
									item_code_pack1_before_item2_in_v_input2_3_copy = v_input2_3_copy[k].item_code;
								}
							}
							if (item_code_pack1_before_item2_in_v_input2_3_copy != v_input2_3_copy[i].item_code) {
								//There is an item with packing load = 1 before item2 in v_input2_3_copy
								int item_index_pack1_before_item2_in_v_input1_copy = -1;
								for (int k = 0; k < v_input1_copy.size(); k++) {
									if (v_input1_copy[k].item_code == item_code_pack1_before_item2_in_v_input2_3_copy) {
										item_index_pack1_before_item2_in_v_input1_copy = k;
										break;
									}
								}
								v_input1_copy.insert(v_input1_copy.begin() + item_index_pack1_before_item2_in_v_input1_copy + 1, v_input1_copy[item1_index_v_input1_copy]);
								v_input1_copy.erase(v_input1_copy.begin() + item1_index_v_input1_copy);
							}
						}
						else if (item1_index_v_input1_copy == -1 && item2_index_v_input1_copy != -1) {
							//The i-th item in v_input2_3_copy doesn't exist in v_input1, while the j-th item in v_input2_3_copy exists in v_input1
							//For example: given v_input2_3_copy = {1A, 2A, 1B, 1C, 2B, 1D} and v_input1_copy = {1A, 1B, 1C, 1D}
							//If 2A and 1C is exchanged in v_input2_3_copy, then 1C must be moved before 1B in v_input1_copy 
							//New sequences: v_input2_3_copy = {1A, 1C*, 1B, 2A*, 2B, 1D} and v_input1_copy = {1A, 1C*, 1B, 1D}
							string item_code_pack1_before_item2_in_v_input2_3_copy = "";
							for (int k = j; k > i; k--) {
								if (v_input2_3_copy[k].pack_load == 1) {
									item_code_pack1_before_item2_in_v_input2_3_copy = v_input2_3_copy[k].item_code;
								}
							}
							if (item_code_pack1_before_item2_in_v_input2_3_copy != v_input2_3_copy[j].item_code) {
								//There is an item with packing load = 1 before item2 in v_input2_3_copy
								int item_index_pack1_before_item2_in_v_input1_copy = -1;
								for (int k = 0; k < v_input1_copy.size(); k++) {
									if (v_input1_copy[k].item_code == item_code_pack1_before_item2_in_v_input2_3_copy) {
										item_index_pack1_before_item2_in_v_input1_copy = k;
										break;
									}
								}
								v_input1_copy.insert(v_input1_copy.begin() + item_index_pack1_before_item2_in_v_input1_copy, v_input1_copy[item2_index_v_input1_copy]);
								v_input1_copy.erase(v_input1_copy.begin() + item2_index_v_input1_copy + 1);
							}
						}

						swap(v_input2_3_copy[i], v_input2_3_copy[j]);

						makeSeqeunce3_begin = clock();

						last_loaded_item_index = makeSeqeunce3(pack_info, v_input1_copy, v_input2_3_copy, v_hanger_copy, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates

						makeSeqeunce3_end = clock();
						makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

						//Used to store the required computational time to execute makeSeqeunce3 procedure
						makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

						calculateTotalCost_begin = clock();
						cur_cost = calculateTotalCost(mix_standard, v_hanger_copy, cost_array, param[0], summary, v_input_check_partial_load);

						calculateTotalCost_end = clock();
						calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

						//Used to store the required computational time to execute makeSeqeunce3 procedure
						calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);
						if (cur_cost <= best_cost) {  // If the move improves the local solution in current iteration, update the local best solution

							if (sameTabuPairExist == 0) {
								vector<string> pairOfItems;
								pairOfItems.push_back(v_input2_3_copy[i].item_code);
								pairOfItems.push_back(v_input2_3_copy[j].item_code);
								tabuList.push_back(pairOfItems);
								tabuListAmount.push_back(1);
								if (tabuList.size() == tabuListSize + 1) {
									tabuListAmount.erase(tabuListAmount.begin());  // Need to be verified (first value in the vector must be removed)
									tabuList.erase(tabuList.begin());  // Need to be verified (first value in the vector must be removed)
								}
							}

							check1 = true;
							best_v_input2_3 = v_input2_3_copy;
							best_v_hangers = v_hanger_copy;

							//Swap same pair of items in v_input1 in order to assure continuous hanging of same items in v_input2_3 and v_input1
							//(When the used set is changed from v_input2_3 to v_input1 due to the hanger's eligibility)
							best_v_input1 = v_input1_copy;

							last_loaded_item_index = -1;  //Used to skip unnecessary swapping candidates

							best_cost = cur_cost;
							best_cost_array = cost_array;
							cost_result.push_back(cost_array);

							summary.mixCost = cost_array[0];
							summary.maxP = cost_array[1];
							summary.capacity_loss = cost_array[2];
							summary.partiallyHungItems = cost_array[3];
							summary.separationPenalty = cost_array[5];

							summary.mixCost_weight = param[0].mix_weight*cost_array[0];
							summary.maxP_weight = param[0].maxP_weight*cost_array[1];
							summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
							summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
							summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

							new_best_in_this_iteration = 1;

							improve_check = true;
						}

						if (sameTabuPairExist == 0) {  // If the move is not included in the tabu list
							if (best_cost < cur_cost) {  // If the move does not improve the local solution in current iteration, update the local best solution after considering the Boltzmann acceptance threshold
								int rand100 = rand() % 101;
								double rand_double = (double)rand100 / 100;

								rand100 = rand() % 101;
								double solution_acceptance_probability = (double)rand100 / 100;
								double boltzmann_threshold = exp(-1 * (cur_cost - best_cost) / temperature);

								if (solution_acceptance_probability < boltzmann_threshold) {
									vector<string> pairOfItems;
									pairOfItems.push_back(v_input2_3_copy[i].item_code);
									pairOfItems.push_back(v_input2_3_copy[j].item_code);
									tabuList.push_back(pairOfItems);
									tabuListAmount.push_back(1);
									if (tabuList.size() == tabuListSize + 1) {
										tabuListAmount.erase(tabuListAmount.begin());  // Need to be verified (first value in the vector must be removed)
										tabuList.erase(tabuList.begin());  // Need to be verified (first value in the vector must be removed)
									}

									check1 = true;
									best_non_tabu_v_input2_3 = v_input2_3_copy;
									best_non_tabu_v_hangers = v_hanger_copy;

									//Swap same pair of items in v_input1 in order to assure continuous hanging of same items in v_input2_3 and v_input1
									//(When the used set is changed from v_input2_3 to v_input1 due to the hanger's eligibility)
									best_non_tabu_v_input1 = v_input1_copy;

									last_loaded_item_index = -1;  //Used to skip unnecessary swapping candidates

									best_non_tabu_cost = cur_cost;
									best_non_tabu_cost_array = cost_array;
									cost_result.push_back(cost_array);  // Maybe this code is not used anywhere

									best_non_tabu_summary.mixCost = cost_array[0];
									best_non_tabu_summary.maxP = cost_array[1];
									best_non_tabu_summary.capacity_loss = cost_array[2];
									best_non_tabu_summary.partiallyHungItems = cost_array[3];
									best_non_tabu_summary.separationPenalty = cost_array[5];

									best_non_tabu_summary.mixCost_weight = param[0].mix_weight*cost_array[0];
									best_non_tabu_summary.maxP_weight = param[0].maxP_weight*cost_array[1];
									best_non_tabu_summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
									best_non_tabu_summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
									best_non_tabu_summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

									improve_check = true;
								}
							}
						}

						if (cur_cost < global_best_cost) {

							improve_check = true;

							global_best_v_input2_3 = v_input2_3_copy;
							global_best_v_hangers = v_hanger_copy;

							//Swap same pair of items in v_input1 in order to assure continuous hanging of same items in v_input2_3 and v_input1
							//(When the used set is changed from v_input2_3 to v_input1 due to the hanger's eligibility)
							global_best_v_input1 = v_input1_copy;

							global_best_summary.mixCost = cost_array[0];
							global_best_summary.maxP = cost_array[1];
							global_best_summary.capacity_loss = cost_array[2];
							global_best_summary.partiallyHungItems = cost_array[3];
							global_best_summary.separationPenalty = cost_array[5];
							global_best_summary.mixCost_weight = param[0].mix_weight*cost_array[0];
							global_best_summary.maxP_weight = param[0].maxP_weight*cost_array[1];
							global_best_summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
							global_best_summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
							global_best_summary.total_objective = global_best_summary.mixCost_weight + global_best_summary.maxP_weight + global_best_summary.capacity_loss_weight + global_best_summary.partiallyHungItems_weight;

							global_best_cost = cur_cost;
							global_best_cost_array = cost_array;
						}

						if (global_best_cost < all_initial_best_cost) {
							all_initial_best_cost = global_best_cost;
							all_initial_best_v_hangers = global_best_v_hangers;
							all_initial_best_summary = global_best_summary;
							all_initial_best_v_input2_3 = global_best_v_input2_3;
							all_initial_best_v_input1 = global_best_v_input1;
						}
					}
				}

				ExitCurrentSearch1:;  //Used to skip unnecessary swapping candidates

				temperature = temperature * temperature_cooling_rate;

				if (new_best_in_this_iteration == 1) {
				}
				else if (best_non_tabu_v_input1.size() != 0) {
					// If there no new best solution in this iteration, find whether any non tabu move solution is accepted, if yes, update solution
					best_v_input1 = best_non_tabu_v_input1;
					best_v_input2_3 = best_non_tabu_v_input2_3;

					best_v_hangers = best_non_tabu_v_hangers;
					best_cost = best_non_tabu_cost;
					best_cost_array = best_non_tabu_cost_array;
					cost_result.push_back(cost_array);

					summary.mixCost = best_non_tabu_summary.mixCost;
					summary.maxP = best_non_tabu_summary.maxP;
					summary.capacity_loss = best_non_tabu_summary.capacity_loss;
					summary.partiallyHungItems = best_non_tabu_summary.partiallyHungItems;
					summary.separationPenalty = best_non_tabu_summary.separationPenalty;

					summary.mixCost_weight = best_non_tabu_summary.mixCost_weight;
					summary.maxP_weight = best_non_tabu_summary.maxP_weight;
					summary.capacity_loss_weight = best_non_tabu_summary.capacity_loss_weight;
					summary.partiallyHungItems_weight = best_non_tabu_summary.partiallyHungItems_weight;
					summary.total_objective = best_non_tabu_summary.total_objective;
				}

				cur_v_hangers = best_v_hangers;  // cur_v_hangers is used to store the current basic v_hangers in the current iteration and check whether any swapping movement can be skipped or not

				consecutiveBestSolutionsOfWholeProblem.push_back(global_best_cost);
				if (consecutiveBestSolutionsOfWholeProblem.size() >= allowedSameConsecutiveObjectiveValuesOfWholeProblem) {
					int allStoredLastObjectivesAreSame = 1;
					for (int i = consecutiveBestSolutionsOfWholeProblem.size() - allowedSameConsecutiveObjectiveValuesOfWholeProblem; i < consecutiveBestSolutionsOfWholeProblem.size(); i++) {
						if (consecutiveBestSolutionsOfWholeProblem[i] != consecutiveBestSolutionsOfWholeProblem[consecutiveBestSolutionsOfWholeProblem.size() - 1]) {
							allStoredLastObjectivesAreSame = 0;
							currentNumberOfSameConsecutiveObjectiveValuesOfWholeProblem = 0;
							break;
						}
					}
					if (allStoredLastObjectivesAreSame == 1) {
						currentNumberOfSameConsecutiveObjectiveValuesOfWholeProblem = currentNumberOfSameConsecutiveObjectiveValuesOfWholeProblem + 1;
					}
					if (currentNumberOfSameConsecutiveObjectiveValuesOfWholeProblem >= allowedSameConsecutiveObjectiveValuesOfWholeProblem) {
						improve_check = false;
					}
				}

				if (improve_check == false)
					break;
			} // while

			initial_item_index = initial_item_index + 1;
			break;  // Only use the best initial item index

			if (initial_item_index == (int)v_input_initial.size()) {
				break;
			}

			for (int i = 0; i < (int)v_input_initial.size(); i++) {
				v_input.push_back(v_input_initial[i]);
			}

			// Selecting an arbitrary initial item, then add other items with the least mixing cost (with last hung item)
			int v_input_size = (int)v_input.size();
			v_input.clear();
			v_input.push_back(v_input_initial_TEMP[best_initial_starting_item_index[initial_item_index]]);
			v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + best_initial_starting_item_index[initial_item_index]);
			while ((int)v_input.size() != v_input_size) {
				int least_mix_cost = 999999999;
				int selected_index = -1;
				int smallest_total_next_mix_cost = 999999999;
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) < least_mix_cost) {
						least_mix_cost = mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]);
					}
				}
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					int total_next_mix_cost = 0;
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
						int i = h;
						for (int j = 0; j < (int)v_input_initial_TEMP.size(); j++) {
							if (i != j) {
								total_next_mix_cost = total_next_mix_cost + mixWeight2(mix_standard, v_input_initial_TEMP[h], v_input_initial_TEMP[i]);;
							}
						}
						if (total_next_mix_cost < smallest_total_next_mix_cost) {
							smallest_total_next_mix_cost = total_next_mix_cost;
							selected_index = h;
						}
					}
				}
				v_input.push_back(v_input_initial_TEMP[selected_index]);
				v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + selected_index);
			}

			for (int i = 0; i < (int)v_input.size(); i++) {
				v_input_initial_TEMP.push_back(v_input_initial[i]);
			}

			v_input1.clear();
			v_input2_3.clear();

			dividInputList(pack_info, v_input, v_input1, v_input2_3, (int)v_hangers.size());

			best_v_input1 = v_input1;
			best_v_input2_3 = v_input2_3;


			// Calculate the objective value of new generated solution

			clock_t makeSeqeunce3_begin = clock();

			last_loaded_item_index = makeSeqeunce3(pack_info, v_input1, v_input2_3, v_hangers, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates
			last_loaded_item_index = -1;  //This value must be updated only during the search with indices i and j

			clock_t makeSeqeunce3_end = clock();
			double makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

			//Used to store the required computational time to execute makeSeqeunce3 procedure
			vector<double> makeSeqeunce3_computationaltime;
			makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

			//initialize
			int count = 1; cost_array[4] = count;

			cost_array[5] = count;

			bool improve_check = true;

			clock_t calculateTotalCost_begin = clock();
			best_cost = calculateTotalCost(mix_standard, v_hangers, cost_array, param[0], summary, v_input_check_partial_load);

			clock_t calculateTotalCost_end = clock();
			double calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

			//Used to store the required computational time to execute makeSeqeunce3 procedure
			vector<double> calculateTotalCost_computationaltime;
			calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);

			summary.mixCost = cost_array[0];
			summary.maxP = cost_array[1];
			summary.capacity_loss = cost_array[2];
			summary.partiallyHungItems = cost_array[3];

			summary.separationPenalty = cost_array[5];

			summary.mixCost_weight = param[0].mix_weight*cost_array[0];
			summary.maxP_weight = param[0].maxP_weight*cost_array[1];
			summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
			summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
			summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

			best_v_input1 = v_input1;
			best_v_input2_3 = v_input2_3;
			best_v_hangers = v_hangers;
			best_cost_array = cost_array;
			cost_result.push_back(cost_array);
		}

		Exitloop1:;

		// Get the global best solution
		v_input1_copy = global_best_v_input1;
		v_input2_3_copy = global_best_v_input2_3;

		v_hanger_copy = v_hangers_org; // v_hangers_org must be kept empty in the whole code (for reseting the hanger contents every time a new schedule is created)
		makeSeqeunce3_begin = clock();

		last_loaded_item_index = makeSeqeunce3(pack_info, v_input1_copy, v_input2_3_copy, v_hanger_copy, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates

		makeSeqeunce3_end = clock();
		makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

		//Used to store the required computational time to execute makeSeqeunce3 procedure
		makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

		calculateTotalCost_begin = clock();

		cur_cost = calculateTotalCost(mix_standard, v_hanger_copy, cost_array, param[0], summary, v_input_check_partial_load);

		calculateTotalCost_end = clock();
		calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

		//Used to store the required computational time to execute makeSeqeunce3 procedure
		calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);

		summary.mixCost = cost_array[0];
		summary.maxP = cost_array[1];
		summary.capacity_loss = cost_array[2];
		summary.partiallyHungItems = cost_array[3];
		summary.separationPenalty = cost_array[5];

		summary.mixCost_weight = param[0].mix_weight*cost_array[0];
		summary.maxP_weight = param[0].maxP_weight*cost_array[1];
		summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
		summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
		summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

		break;

	case 2://2-opt
		global_count = 0;
		while (true) {
			bool check1 = false;
			bool check2 = false;
			improve_check = true;
			count = 0;

			while (improve_check) {
				improve_check = false;

				v_input1_copy = best_v_input1;
				v_input2_3_copy = best_v_input2_3;

				for (int i = 0; i < v_input2_3_copy.size() - 1; i++) {
					for (int j = i + 1; j < v_input2_3_copy.size(); j++) {

						clock_t end = clock();
						double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;

						if (elapsed_secs > totalTimeLimit) {
							goto Exitloop2;
						}

						if (i > last_loaded_item_index && last_loaded_item_index != -1) {
							goto ExitCurrentSearch2;  //Used to skip unnecessary swapping candidates
						}

						//Do not perform search if items type i and j:
						//1.Have same packing load
						//2.Have same characteristics which affects the mixing costs
						//3.Require same number of hangers (considering total number of items, possible number of hung items in a hanger, and required number of hangers per item
						if (v_input2_3_copy[i].pack_load == v_input2_3_copy[j].pack_load
							&& v_input2_3_copy[i].type_code == v_input2_3_copy[j].type_code && v_input2_3_copy[i].pack_type == v_input2_3_copy[j].pack_type
							&& v_input2_3_copy[i].item_name == v_input2_3_copy[j].item_name && v_input2_3_copy[i].sub_assembly_name == v_input2_3_copy[j].sub_assembly_name
							&& v_input2_3_copy[i].car_model == v_input2_3_copy[j].car_model
							&& v_input2_3_copy[i].amount / v_input2_3_copy[i].capa * v_input2_3_copy[i].needed_hanger == v_input2_3_copy[j].amount / v_input2_3_copy[j].capa * v_input2_3_copy[j].needed_hanger)
							continue;

						cost_array[4] = 0;

						v_hanger_copy = v_hangers_org; // v_hangers_org must be kept empty in the whole code(for reseting the hanger contents every time a new schedule is created)

						int item1_index_v_input1_copy = -1;
						int item2_index_v_input1_copy = -1;
						for (int k = 0; k < v_input1_copy.size(); k++) {
							if (v_input1_copy[k].item_code == v_input2_3_copy[i].item_code) {
								item1_index_v_input1_copy = k;
							}
							if (v_input1_copy[k].item_code == v_input2_3_copy[j].item_code) {
								item2_index_v_input1_copy = k;
							}
						}
						if (item1_index_v_input1_copy != -1 && item2_index_v_input1_copy != -1) {
							//If both items exist in v_input1_copy, swap their positions
							swap(v_input1_copy[item1_index_v_input1_copy], v_input1_copy[item2_index_v_input1_copy]);
						}
						else if (item1_index_v_input1_copy != -1 && item2_index_v_input1_copy == -1) {
							//The i-th item in v_input2_3_copy exists in v_input1, while the j-th item in v_input2_3_copy doesn't exist in v_input1
							//For example: given v_input2_3_copy = {1A, 2A, 1B, 1C, 2B, 1D} and v_input1_copy = {1A, 1B, 1C, 1D}
							//If 1A and 2B is exchanged in v_input2_3_copy, then 1A must be moved after 1C in v_input1_copy 
							//New sequences: v_input2_3_copy = {2B*, 2A, 1B, 1C, 1A*, 1D} and v_input1_copy = {1B, 1C, 1A*, 1D}
							string item_code_pack1_before_item2_in_v_input2_3_copy = "";
							for (int k = i; k < j; k++) {
								if (v_input2_3_copy[k].pack_load == 1) {
									item_code_pack1_before_item2_in_v_input2_3_copy = v_input2_3_copy[k].item_code;
								}
							}
							if (item_code_pack1_before_item2_in_v_input2_3_copy != v_input2_3_copy[i].item_code) {
								//There is an item with packing load = 1 before item2 in v_input2_3_copy
								int item_index_pack1_before_item2_in_v_input1_copy = -1;
								for (int k = 0; k < v_input1_copy.size(); k++) {
									if (v_input1_copy[k].item_code == item_code_pack1_before_item2_in_v_input2_3_copy) {
										item_index_pack1_before_item2_in_v_input1_copy = k;
										break;
									}
								}
								v_input1_copy.insert(v_input1_copy.begin() + item_index_pack1_before_item2_in_v_input1_copy + 1, v_input1_copy[item1_index_v_input1_copy]);
								v_input1_copy.erase(v_input1_copy.begin() + item1_index_v_input1_copy);
							}
						}
						else if (item1_index_v_input1_copy == -1 && item2_index_v_input1_copy != -1) {
							//The i-th item in v_input2_3_copy doesn't exist in v_input1, while the j-th item in v_input2_3_copy exists in v_input1
							//For example: given v_input2_3_copy = {1A, 2A, 1B, 1C, 2B, 1D} and v_input1_copy = {1A, 1B, 1C, 1D}
							//If 2A and 1C is exchanged in v_input2_3_copy, then 1C must be moved before 1B in v_input1_copy 
							//New sequences: v_input2_3_copy = {1A, 1C*, 1B, 2A*, 2B, 1D} and v_input1_copy = {1A, 1C*, 1B, 1D}
							string item_code_pack1_before_item2_in_v_input2_3_copy = "";
							for (int k = j; k > i; k--) {
								if (v_input2_3_copy[k].pack_load == 1) {
									item_code_pack1_before_item2_in_v_input2_3_copy = v_input2_3_copy[k].item_code;
								}
							}
							if (item_code_pack1_before_item2_in_v_input2_3_copy != v_input2_3_copy[j].item_code) {
								//There is an item with packing load = 1 before item2 in v_input2_3_copy
								int item_index_pack1_before_item2_in_v_input1_copy = -1;
								for (int k = 0; k < v_input1_copy.size(); k++) {
									if (v_input1_copy[k].item_code == item_code_pack1_before_item2_in_v_input2_3_copy) {
										item_index_pack1_before_item2_in_v_input1_copy = k;
										break;
									}
								}
								v_input1_copy.insert(v_input1_copy.begin() + item_index_pack1_before_item2_in_v_input1_copy, v_input1_copy[item2_index_v_input1_copy]);
								v_input1_copy.erase(v_input1_copy.begin() + item2_index_v_input1_copy + 1);
							}
						}

						swap(v_input2_3_copy[i], v_input2_3_copy[j]);

						makeSeqeunce3_begin = clock();

						last_loaded_item_index = makeSeqeunce3(pack_info, v_input1_copy, v_input2_3_copy, v_hanger_copy, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates

						makeSeqeunce3_end = clock();
						makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

						//Used to store the required computational time to execute makeSeqeunce3 procedure
						makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

						calculateTotalCost_begin = clock();
						cur_cost = calculateTotalCost(mix_standard, v_hanger_copy, cost_array, param[0], summary, v_input_check_partial_load);

						calculateTotalCost_end = clock();
						calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

						//Used to store the required computational time to execute makeSeqeunce3 procedure
						calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);

						if (cur_cost < best_cost) {
							count++;

							check1 = true;

							best_v_input2_3 = v_input2_3_copy;
							best_v_hangers = v_hanger_copy;

							//Swap same pair of items in v_input1 in order to assure continuous hanging of same items in v_input2_3 and v_input1
							//(When the used set is changed from v_input2_3 to v_input1 due to the hanger's eligibility)
							best_v_input1 = v_input1_copy;

							last_loaded_item_index = -1;  //Used to skip unnecessary swapping candidates

							best_cost = cur_cost;
							best_cost_array = cost_array;
							cost_result.push_back(cost_array);

							summary.mixCost = cost_array[0];
							summary.maxP = cost_array[1];
							summary.capacity_loss = cost_array[2];
							summary.partiallyHungItems = cost_array[3];
							summary.separationPenalty = cost_array[5];

							summary.mixCost_weight = param[0].mix_weight*cost_array[0];
							summary.maxP_weight = param[0].maxP_weight*cost_array[1];
							summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
							summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
							summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

							improve_check = true;
						}
					}
				}

				ExitCurrentSearch2:;  // Used to skip unnecessary swapping candidates

				v_input1_copy = best_v_input1;
				v_input2_3_copy = best_v_input2_3;

				if (improve_check == false)
					break;

				if (count >= 100) {
					log_out << "seems infinite-1" << endl;
					break;
				}
			} // while

			// Try to generate other items as the first item in sequence to generate a new initial solution
			if (best_cost < all_initial_best_cost) {
				all_initial_best_cost = best_cost;
				all_initial_best_v_hangers = best_v_hangers;
				all_initial_best_summary = summary;
				all_initial_best_v_input2_3 = best_v_input2_3;
				all_initial_best_v_input1 = best_v_input1;
			}

			initial_item_index = initial_item_index + 1;
			break;  // Only use the best initial item index

			if (initial_item_index == (int)v_input_initial.size()) {
				break;
			}

			for (int i = 0; i < (int)v_input_initial.size(); i++) {
				v_input.push_back(v_input_initial[i]);
			}

			// Selecting an arbitrary initial item, then add other items with the least mixing cost (with last hung item)
			int v_input_size = (int)v_input.size();
			v_input.clear();
			v_input.push_back(v_input_initial_TEMP[best_initial_starting_item_index[initial_item_index]]);
			v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + best_initial_starting_item_index[initial_item_index]);

			while ((int)v_input.size() != v_input_size) {
				int least_mix_cost = 999999999;
				int selected_index = -1;
				int largest_total_next_mix_cost = -1;
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) < least_mix_cost) {
						least_mix_cost = mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]);
					}
				}
				for (int h = 0; h < (int)v_input_initial_TEMP.size(); h++) {
					int total_next_mix_cost = 0;
					if (mixWeight2(mix_standard, v_input[(int)v_input.size() - 1], v_input_initial_TEMP[h]) == least_mix_cost) {
						int i = h;
						for (int j = 0; j < (int)v_input_initial_TEMP.size(); j++) {
							if (i != j) {
								total_next_mix_cost = total_next_mix_cost + mixWeight2(mix_standard, v_input_initial_TEMP[h], v_input_initial_TEMP[i]);;
							}
						}
						if (total_next_mix_cost > largest_total_next_mix_cost) {
							largest_total_next_mix_cost = total_next_mix_cost;
							selected_index = h;
						}
					}
				}
				v_input.push_back(v_input_initial_TEMP[selected_index]);
				v_input_initial_TEMP.erase(v_input_initial_TEMP.begin() + selected_index);
			}

			for (int i = 0; i < (int)v_input.size(); i++) {
				v_input_initial_TEMP.push_back(v_input_initial[i]);
			}

			v_input1.clear();
			v_input2_3.clear();

			dividInputList(pack_info, v_input, v_input1, v_input2_3, (int)v_hangers.size());

			best_v_input1 = v_input1;
			best_v_input2_3 = v_input2_3;


			// Calculate the objective value of new generated solution

			clock_t makeSeqeunce3_begin = clock();

			last_loaded_item_index = makeSeqeunce3(pack_info, v_input1, v_input2_3, v_hangers, 0, last_loaded_item_index);  //Used to skip unnecessary swapping candidates
			last_loaded_item_index = -1;  //This value must be updated only during the search with indices i and j

			clock_t makeSeqeunce3_end = clock();
			double makeSeqeunce3_elapsed_secs = double(makeSeqeunce3_end - makeSeqeunce3_begin) / CLOCKS_PER_SEC;

			//Used to store the required computational time to execute makeSeqeunce3 procedure
			vector<double> makeSeqeunce3_computationaltime;
			makeSeqeunce3_computationaltime.push_back(makeSeqeunce3_elapsed_secs);

			//initialize
			int count = 1; cost_array[4] = count;

			cost_array[5] = count;

			bool improve_check = true;

			clock_t calculateTotalCost_begin = clock();
			best_cost = calculateTotalCost(mix_standard, v_hangers, cost_array, param[0], summary, v_input_check_partial_load);

			clock_t calculateTotalCost_end = clock();
			double calculateTotalCost_elapsed_secs = double(calculateTotalCost_end - calculateTotalCost_begin) / CLOCKS_PER_SEC;

			//Used to store the required computational time to execute makeSeqeunce3 procedure
			vector<double> calculateTotalCost_computationaltime;
			calculateTotalCost_computationaltime.push_back(calculateTotalCost_elapsed_secs);

			summary.mixCost = cost_array[0];
			summary.maxP = cost_array[1];
			summary.capacity_loss = cost_array[2];
			summary.partiallyHungItems = cost_array[3];

			summary.separationPenalty = cost_array[5];

			summary.mixCost_weight = param[0].mix_weight*cost_array[0];
			summary.maxP_weight = param[0].maxP_weight*cost_array[1];
			summary.capacity_loss_weight = param[0].loss_weight*cost_array[2];
			summary.partiallyHungItems_weight = param[0].partial_weight*cost_array[3];
			summary.total_objective = summary.mixCost_weight + summary.maxP_weight + summary.capacity_loss_weight + summary.partiallyHungItems_weight;

			best_v_input1 = v_input1;
			best_v_input2_3 = v_input2_3;
			best_v_hangers = v_hangers;
			best_cost_array = cost_array;
			cost_result.push_back(cost_array);
		}
		Exitloop2:;

		break;

	default:
		log_out << "The inputted algorithm number is not within the range. The program is terminated." << endl;
		throw 4;
		break;
	}

	// Store best solution obtain among all initial solutions
	v_input1_copy = all_initial_best_v_input1;
	v_input2_3_copy = all_initial_best_v_input2_3;
	v_hangers = all_initial_best_v_hangers;
	summary = all_initial_best_summary;
	v_input = all_initial_best_v_input2_3;
	best_cost = all_initial_best_cost;

	best_v_input1 = v_input1_copy;
	best_v_input2_3 = v_input2_3_copy;
	best_v_hangers = v_hangers;

	Exitloop3:;

	v_hangers.clear();
	v_hangers = best_v_hangers;
	v_input = best_v_input2_3;
}

c_parameter::c_parameter(double loss_weight, double partial_weight, double mix_weight, double maxP_weight)
{
	this->loss_weight = loss_weight;
	this->partial_weight = partial_weight;
	this->mix_weight = mix_weight;
	this->maxP_weight = maxP_weight;
}