#pragma once

#include "item.h"
#include "hanger.h"
#include <vector>
#include <iostream>

class c_operation {
	string type_code, pack_code, item_code, insert_date, insert_time, operation_code, operation_date, schdule_code, hanger_code;
	int amt, start_hanger_num, end_hanger_num;

public:

	c_item cur_item;
	c_hanger cur_hanger; // (not used)
	c_hanger next_hanger; // (not used)
	c_hanger start_hanger; // start hanger
	c_hanger end_hanger; // end hanger
	int total_hanged_amt;
	c_operation() {};
	c_operation(c_item _cur_item, c_hanger _start_hanger)
		:cur_item(_cur_item), start_hanger(_start_hanger) {
		this->start_hanger.insert_time_hhmmsec = _start_hanger.insert_time_hhmmsec;
	};
	c_operation(string _type_code, string _pack_code, string _item_code, int _amt, string _insert_date, string _insert_time, int _start_hanger_num,
		int _end_hanger_num, string _operation_code, string _operation_date, string _schdule_code, string _hanger_code);
	c_operation(c_item _cur_item, c_hanger _cur_hanger, c_hanger _next_hanger)
		:cur_item(_cur_item), cur_hanger(_cur_hanger), next_hanger(_next_hanger) {};
};

void make_operation3(vector<c_hanger>& hangerContainer, vector<c_operation>& operationContainer);
void writeSchedule(vector<c_hanger>& hangerContainer, vector<c_operation>& operationContainer, char* filename);
void writeScheduleOnHangers(vector<c_hanger>& v_hangers, vector<c_item>& v_items_to_schedule, char* filename);
void resultCheck(vector<c_hanger> & hangerContainer, vector<c_operation> &operationContainer, char* filename);