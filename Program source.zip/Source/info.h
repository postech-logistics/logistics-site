#pragma once
#include <string>
#include <iostream>
#include <vector>
#include "item.h"

using namespace std;

class c_info {
public:
	string item_code;
	string type_code;
	string line_code;
	bool main_line; // Main line checking
	int needed_hanger;
	double hanger_capa; // Capacity per hanger
	int voltage; // Painting voltage
	bool small_hang; // Small hanger requirement
	c_info();
	c_info(string _item_code, string _type_code, string _line_code,
		bool _main_line, int _needed_hanger, double _hanger_capa,
		int _voltage, bool _small_hang);

};