#pragma once
#include "item.h"
#include "hanger.h"
#include "operation.h"
#include <vector>
#include <iostream>
#include <algorithm>
#include "mix_standard.h"
#include <cmath>
#include "result_summary.h"


class c_parameter {
public:
	double loss_weight;
	double partial_weight;
	double mix_weight;
	double maxP_weight;

	c_parameter(double loss_weight, double partial_weight, double mix_weight, double maxP_weight);
};

int mixWeight2(vector<c_mix_standard> &mix_standard, c_item& item1, c_item& item2);
double calculateMixCost(vector<c_mix_standard> &mix_standard, vector<c_hanger>& hangerContainer, result_summary &summary);
double calculateLoss(vector<c_hanger>& hangerContainer);

double calculateTotalCost(vector<c_mix_standard>& mix_standard, vector<c_hanger>& hangerContainer, vector <double> &cost_array, c_parameter &param, result_summary &summary, vector<c_item>& v_input_check_partial_load);

void readParameters(char* filename, vector<c_parameter>& param);

void read_list_of_items_in_stored_best_initial_sequence(char * filename5, vector<string>& temp_best_v_selected_random_no_for_initial_sequence);

int makeSeqeunce3(vector<pack>& pack_info, vector<c_item>& v_input1, vector<c_item>& v_input_2_3, vector<c_hanger>& v_hangers, int mode, int last_loaded_item_index);

void simple_heuristic(vector<c_item>& v_input, vector<c_hanger>& v_hangers, vector<c_parameter> &param, vector<pack>& pack_info, vector<c_mix_standard>& mix_standard, result_summary &summary, int algorithm_type);