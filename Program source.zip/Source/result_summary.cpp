#include "result_summary.h"

void write_summary(result_summary & summary, char * filename, double elapsed_secs)
{
	ofstream fout;
	fout.open(filename);
	if (fout.is_open()) {

		fout << "capacity_loss_objective,partial_scheduled_items_objective,mixing_objective,MaxP_objective" << endl;
		fout << summary.capacity_loss << ',' << summary.partiallyHungItems << ',' << summary.mixCost << ',' << summary.maxP << endl;
		fout << endl;

		fout << "weighted_capacity_loss_objective,weighted_partial_scheduled_items_objective,weighted_mixing_objective,weighted_MaxP_objective,total_objective" << endl;
		fout << summary.capacity_loss_weight << ',' << summary.partiallyHungItems_weight << ',' << summary.mixCost_weight << ',' << summary.maxP_weight << ',' << summary.total_objective << endl;
		fout << endl;

		fout << "elapsed_secs" << endl;
		fout << elapsed_secs << endl;
		fout << flush;
		fout.close();
	}
	else {

		ofstream fout;
		fout.open("log_file.txt");
		if (fout.is_open()) {
			fout << "Cannot open summary file" << endl;
			fout.close();
		}
		log_out << filename << "cannot be opened" << endl;
		throw - 1;
	}
}