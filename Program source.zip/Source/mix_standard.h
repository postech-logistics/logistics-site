#pragma once
#include <vector>
#include "item.h"
#include<iostream>

using namespace std;

class c_mix_standard {
public:
	int mix_penalty;
	bool type;
	bool pack;
	bool item_name; // Boolean for checking whether the item_name matches or not
	bool sub_assembly;
	bool car_model; // Car's model code
	
	c_mix_standard(int _penalty, bool _type, bool _pack, bool _item_name, bool _sub_assembly, bool _car_model)
		: mix_penalty(_penalty), type(_type), pack(_pack), item_name(_item_name), sub_assembly(_sub_assembly), car_model(_car_model) {}

};
void read_mix_standard_info(vector<c_mix_standard> &mix_standard, char* filename);
int search_penalty(vector<c_mix_standard> &mix_standard, bool _type, bool _pack, bool _item_name, bool _sub_assembly, bool _model);