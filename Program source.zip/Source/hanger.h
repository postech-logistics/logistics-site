#pragma once
#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>
#include "item.h"
#define NOTHING 1
#define INNER_ONLY 2
#define NON_PACK 3
#define EVERYTHING 4

class c_hanger {
public:
	bool full;
	int hanger_num; // Based on the order in the input
	int hanger_num_original; // hanger_num_original of the basic hangers
	bool liquid_check;
	double capacity_percentage;
	int available_group; // 1 = nothing, 2 = only for interior items, 3 = unpacked items (during lunch), 4 = everything
	int insert_time; // Insertion time of a hanger
	string insert_time_hhmmsec;
	std::vector<c_item> item_list;
	std::vector<int> item_amt;

	c_hanger();
	c_hanger(int _hanger_num);
	void hang(c_item& item, int& amt);
	bool last;
	bool eligibility_check(c_item& item);

};
class c_basic_hanger {
public:
	int hanger_num_original;
	int liquid_check;
	c_basic_hanger(int _hanger_num, int _liquid_check) :hanger_num_original(_hanger_num), liquid_check(_liquid_check) {}
};
void setHangerClear(vector<c_hanger>& v_hangers);

void read_hanger_input(vector<c_hanger>& v_hangers, char* filename);