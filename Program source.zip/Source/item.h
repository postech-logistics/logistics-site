#pragma once

#include <string>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
extern ofstream log_out;
class c_item {
public:

	string item_code;
	string type_code;
	string item_name;
	double amount;
	double remained_amount;
	double capa; // Amount per hanger
	int needed_hanger; // Number of required hangers
	int voltage; // Required voltage for painting
	string sub_assembly_name;
	vector<string> sub_assembly_name_split_by_comma; // Vector for splitting sub_assembly_name using ','
	string item_group;
	string pack_type; // Packing type
	int pack_load; // Packing load
	int maxHangerNum; // Maximum number of consecutive hangers
	int min_middle_nonpack; // Minimum amount of not packed items placed in between
	int max_middle_nonpack; // Maximum amount of not packed items placed in between
	int dayMaxHanger;;
	string car_model; // Car's model code
	
	c_item();
	c_item(string inp_num, int inp_ord, string inp_time, string inp_comp,
		string itm_code, string typ_code, string prd_type, string itm_name, double amt);

	c_item(string type_code, string item_code);

	c_item(double amount, string available, double capa, string car_model, string car_model_name, int dayMaxHanger, string input_comp, string input_num, int input_order,
		string input_time, string item_code, string item_group, string item_name, string sub_assembly_name, string line_code, bool main_line, int maxHangerNum, int max_middle_nonpack, int min_middle_nonpack,
		int needed_hanger, int pack_load, string pack_type, string product_type, double remain, double remained_amount, bool small_hang, string type_code, int voltage);
};
struct pack {
	string packType;
	int workLoad;
	int maxHangerNum;
	int min_middle_nonpack;
	int max_middle_nonpack;
	int dayMaxHanger;
	double amount_sum;
	double total_amount_sum; // Total production amount in a day
	int start_hanger_index;
};

void readPackInfo(char* filename, std::vector<pack>& v_pack);

void read_item_info(char* filename, std::vector<c_item>& v_items_to_schedule);