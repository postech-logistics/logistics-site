#pragma once

#include "hanger.h"
#include "item.h"
#include "heuristics.h"
#include <vector>
#include <iostream>
#include <algorithm>
#include <ctime>

class C_line {
public:
	int start_time_hhmm;
	int finish_time_hhmm;
	int sec_per_hanger;
	int hanger_num;
	int start_hanger_num;
	bool am_break;
	bool pm_break;
	bool lunch_break;
	bool dinner_break;
	int am_break_start_hhmm;
	int am_break_finish_hhmm;
	int pm_break_start_hhmm;
	int pm_break_finish_hhmm;
	int lunch_start_hhmm;
	int lunch_finish_hhmm;
	int dinner_start_hhmm;
	int dinner_finish_hhmm;
};