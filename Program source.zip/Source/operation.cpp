#include "operation.h"
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

// Checking whether the solution already exists or not
bool find_in_list(c_item &temp_item, vector<c_operation>& operationContainer)
{
	for (int j = 0; j < (int)operationContainer.size(); j++) {
		if (operationContainer[j].cur_item.item_code == temp_item.item_code
			&&operationContainer[j].cur_item.type_code == temp_item.type_code)
			return true;
	}
	return false;
}

bool compareOpCont(c_operation &e1, c_operation &e2)
{
	return e1.start_hanger.hanger_num < e2.start_hanger.hanger_num;
}

void make_operation3(vector<c_hanger>& hangerContainer, vector<c_operation>& operationContainer) { // There can be several operations for one item
	operationContainer.clear();
	for (int i = 0; i < hangerContainer.size(); i++) {
		for (int j = 0; j < (int)hangerContainer[i].item_list.size(); j++) {
			c_item temp_item = hangerContainer[i].item_list[j];
			if (find_in_list(temp_item, operationContainer) == false) {
				c_operation temp_op(temp_item, hangerContainer[i]);
				operationContainer.push_back(temp_op);
			}
		}
	}

	vector<c_operation> additional_operationContainer;

	for (int k = 0; k < (int)operationContainer.size(); k++) {
		bool check = false;
		operationContainer[k].total_hanged_amt = 0;
		int previous_index = -1;
		c_operation temp_operation;

		bool new_start = false;
		for (int i = 0; i< (int)hangerContainer.size(); i++) {
			for (int j = 0; j < (int)hangerContainer[i].item_list.size(); j++) {
				if (operationContainer[k].cur_item.item_code == hangerContainer[i].item_list[j].item_code
					&&operationContainer[k].cur_item.type_code == hangerContainer[i].item_list[j].type_code) {
					if (previous_index == -1 || previous_index == i - 1) {
						if (new_start == false) {
							operationContainer[k].total_hanged_amt += hangerContainer[i].item_amt[j];
							operationContainer[k].end_hanger = hangerContainer[i];
						}
						else {
							temp_operation.total_hanged_amt += hangerContainer[i].item_amt[j];
							temp_operation.end_hanger = hangerContainer[i];
						}
					}
					else {
						if (new_start == true) {
							additional_operationContainer.push_back(temp_operation);
						}
						temp_operation = operationContainer[k];
						temp_operation.total_hanged_amt = hangerContainer[i].item_amt[j];
						temp_operation.start_hanger = hangerContainer[i];
						temp_operation.end_hanger = hangerContainer[i];
						new_start = true;
					}
					previous_index = i;
					check = true;
				}
			}
		}
		if (new_start == true) {
			additional_operationContainer.push_back(temp_operation);
		}
	}
	operationContainer.insert(operationContainer.begin(), additional_operationContainer.begin(), additional_operationContainer.end());
	sort(operationContainer.begin(), operationContainer.end(), compareOpCont);

	

}

void writeSchedule(vector<c_hanger>& hangerContainer, vector<c_operation>& operationContainer, char* filename) {

	ofstream fout;
	fout.open(filename);
	if (fout.is_open()) {
		/***** Order information *****/
		fout << "item_code" << ',' << "initial_hanger_number_that_has_item_i(s_i)" << ',' << "final_hanger_number_that_has_item_i(r_i)" << ',' << "total_amount_of_hung_items(sigma_h(x_ih))" 
			<< ',' << "required_number_of_hangers_per_item_i(d_i)" << ',' << "sigma_h(x_ih)*d_i" << endl;
		for (int i = 0; i < (int)operationContainer.size(); i++) {
			int null_count = 0;
			for (int k = operationContainer[i].start_hanger.hanger_num; k <= operationContainer[i].end_hanger.hanger_num; k++)
				if (hangerContainer[k].available_group == NOTHING)
					null_count++;
			fout << operationContainer[i].cur_item.item_code << ',' << operationContainer[i].start_hanger.hanger_num << ',' << operationContainer[i].end_hanger.hanger_num << 
				',' << operationContainer[i].total_hanged_amt / operationContainer[i].cur_item.needed_hanger << ',' << operationContainer[i].cur_item.needed_hanger <<
				',' << operationContainer[i].total_hanged_amt << endl;
		}

		fout << flush;
		fout.close();

		
	}
	else {
		log_out << filename << "cannot be opened" << endl;
		throw - 1;

	}
}

void writeScheduleOnHangers(vector<c_hanger>& v_hangers, vector<c_item>& v_input_items, char* filename) {

	cout << "item on hangers (before calculating objective values)" << endl;

	for (int h = 0; h < (int)v_hangers.size(); h++) {
		cout << "hanger = " << h << endl;
		for (int k = 0; k < v_hangers[h].item_list.size(); k++) {
			cout << "-> item_code: " << v_hangers[h].item_list[k].item_code << ", amount = " << v_hangers[h].item_amt[k] << ", capacity = " << v_hangers[h].item_list[k].capa << endl;
		}
	}

	ofstream fout;
	fout.open(filename);
	if (fout.is_open()) {

		int max_num_of_item_types_on_a_hanger = 0;
		for (int h = 0; h < v_hangers.size(); h++)
			if (v_hangers[h].item_list.size() > max_num_of_item_types_on_a_hanger)
				max_num_of_item_types_on_a_hanger = v_hangers[h].item_list.size();

		fout << "hanger_index(h)" << ',';
		for (int i = 0; i < max_num_of_item_types_on_a_hanger; i++)
			fout << "item_code(i)" << ',' << "number_of_items_i_on_hanger_h(x_ih)" << ',';
		fout << endl;

		for (int h = 0; h < v_hangers.size(); h++) {
			fout << h + 1 << ',';
			for (int i = 0; i < v_hangers[h].item_list.size(); i++) {
				fout << v_hangers[h].item_list[i].item_code << ',' << v_hangers[h].item_amt[i] << ',';
			}
			fout << endl;
		}

		fout << flush;
		fout.close();

	}
	else {
		log_out << filename << "writeScheduleOnHangers cannot be executed" << endl;
		throw - 1;

	}
}

void resultCheck(vector<c_hanger>& hangerContainer, vector<c_operation>& operationContainer, char * filename) {
	ofstream fout;
	fout.open(filename);
	if (fout.is_open()) {
		/***** Order information *****/
		fout << "item code" << ',' << "item type code" << ',' << "start hanger insert time" << ',' << "start hanger number" << ',' << "end hanger number" << ',' << "ordered number of hangers" << ','
			<< "total amount" << ','
			<< "capacity per hanger " << ',' << "required number of hangers" << ',' << "number of used hangers" << ',' << endl;

		for (int i = 0; i < (int)operationContainer.size(); i++) {
			int null_count = 0;
			for (int k = operationContainer[i].start_hanger.hanger_num; k <= operationContainer[i].end_hanger.hanger_num; k++)
				if (hangerContainer[k].available_group == NOTHING)
					null_count++;

			fout << operationContainer[i].cur_item.item_code << ',' << operationContainer[i].cur_item.type_code << ',' << operationContainer[i].start_hanger.insert_time_hhmmsec << ','
				<< operationContainer[i].start_hanger.hanger_num + 1 << ',' << operationContainer[i].end_hanger.hanger_num + 1 << ',' << operationContainer[i].total_hanged_amt / operationContainer[i].cur_item.needed_hanger << ','
				<< operationContainer[i].cur_item.amount << ','
				<< operationContainer[i].cur_item.capa << ',' << operationContainer[i].cur_item.needed_hanger << ',' << (operationContainer[i].end_hanger.hanger_num - operationContainer[i].start_hanger.hanger_num + 1 - null_count) << ',' << endl;
		}
		fout.close();
	}
	else {
		log_out << filename << "cannot be opened" << endl;
		throw - 1;

	}
}

c_operation::c_operation(string _type_code, string _pack_code, string _item_code, int _amt, string _insert_date, string _insert_time, int _start_hanger_num,
	int _end_hanger_num, string _operation_code, string _operation_date, string _schdule_code, string _hanger_code)
	: type_code(_type_code), pack_code(_pack_code), item_code(_item_code), insert_date(_insert_date), insert_time(_insert_time), operation_code(_operation_code),
	operation_date(_operation_date), schdule_code(_schdule_code), hanger_code(_hanger_code), amt(_amt), start_hanger_num(_start_hanger_num), end_hanger_num(_end_hanger_num) {
	this->cur_item = c_item(type_code, item_code);
	this->start_hanger = c_hanger(start_hanger_num);
	this->end_hanger = c_hanger(end_hanger_num);
}