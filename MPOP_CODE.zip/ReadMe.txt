How to run the batch file:
- To run the batch executable file, you need to keep all folders unzipped from MPOP_Benchmark_instances.zip.
- By double left-clicking "batch.bat" in the "sample_run" folder, you can solve the MPOP instance using a selected SA or SA+VTOA.
- You may edit "batch.bat" file by right-clicking it and select "Edit".

Contents of the batch file are:
<executable program> <algorithm selection> <iteration> <2 input files> <1 output file> 

<executable program>: MPOP.exe

<algorithm selection>: 0 for SA, 1 for SA+VTOA (VTOA embedded in  Move Step), 2 for SA+VTOA (VTOA embedded in Acceptance step), 3 for SA+VTOA  (VTOA embedded in Best Update step)
*To reduce the computational burden, this study performs the VTOA in the Best Update step (Step 4) of SA+VTOA. [algorithm selection : 3]

<iteration> : # of iterations of the experiments

<2 input file>:
(a) MPOPData.csv:
List of each node with the following information: Node,  X Coordinate, Y Coordinate, NodeType(0:start 1:end 2:intermediate), Morning Score, Afternoon Score, Evening Score.

(b) OptionFile.csv
List of options with the following information: Time Limit, time range of Morning, Afternoon, and Evening.

<n output file> [n= # of iterations of the experiments]
(a) MPOPSolution_ith.csv
"MPOPSolution_ith.csv" is a file that outputs the solution of the ith experiment. 
The experimental results with the following information: route (path) of the vehicle, Total Profit, Computational time. 

Since we used random seeds in the experiment in this paper, the experimental results can be changed each time. 
The experimental results of the paper can be accessed from "MPOP_best_known_solution_results".zip.

** By Downloading the Julia, unzipping "MPOP_CPLEX_CODE.zip," and setting the input and output file names in "MPOP.jl", you can solve the instance using the mathematical model of MPOP in Julia.