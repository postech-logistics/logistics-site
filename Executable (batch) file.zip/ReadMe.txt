How to run the batch file:
- To run the batch executable file, you need to keep all folders unzipped from Painting_Line_Scheduling.zip.
- By double left-clicking "single_run.bat", you are solving one instance using a selected 2-Opt or Tabu Search algorithm.
- By double left-clicking "batch_run.bat", you are solving 35 instances using both 2-Opt and Tabu Search algorithms. (Each line in the batch file corresponds to solving one instance using one algorithm).
- You may edit "single_run.bat" or "batch_run.bat" file by right-clicking it and select "Edit". 

Contents of the batch file are:
<executable program> <algorithm selection> <5 input files> <3 output files>

<executable program>: Painting_Line_Scheduling.exe

<algorithm selection>: 1 for Tabu Search, 2 for 2-Opt algorithm

<5 input files>:
(a) packing_information.csv:
List of each packing type of the items with the following information: packing workload level, allowed number of consecutive hangers with the packing type in the schedule, minimum and maximum required number of hangers with packing workload 1 items between the packing type, maximum number of hangers per day that contain the packing workload.

(b) parameter.csv
Weights of the objective (capacity loss of hangers, partial scheduled items, penalty for mixing different items, total amount of packing workload on consecutive hangers)

(c) mix_information.csv
Mixing penalties given based on the similarity level in: item_type_code, packing_type, item_name, sub_assembly_name, car_model

(d) v_items_to_schedule.csv 
Information of items to be hung with the following information: item_code, item_name, number of items, occupied hanger capacity by the item, required number of consecutive hanger(s) for one item, packing workload, maximum number of consecutive hangers, maximum and minimum number of hangers with packing workload 1 between the item, maximum number of hangers in the schedule, type_code, pack_type, sub_assembly_name, car_model, item_group.

(e) hanger_input.csv
Index of hangers and allowed item_group to be hung on each hanger.
Eligibility of items on the hangers are restricted as follows:
- hanger.available_group = 1: no items
- hanger.available_group = 2: items with item_group == "BP02", "BP02 ", "E001", "PP01", "ZZZZ", or items with pack_load <= 1
- hanger.available_group = 3: items with type_code == "DK", "DH ", or items with pack_load <= 2
- hanger.available_group = 4: any items

<3 output files>
(a) production_plan_order.csv
Code of hung items with the following information: initial and final hanger number that has the item, total amount of hung items, required number of hangers per item, and multiplication of last two terms (to be compared with the total values in hanger_summary.csv).
(b) summary.csv
Objective values (total amount of packing workload on consecutive hangers, penalty for mixing different items, capacity loss of hangers, partial scheduled items), weighted objective values, and required computational time.
(c) hanger_summary.csv
Index of hangers and list of items (code and number of items) hung on each hanger.